/*! aladdin.clipboard v1.0.0 (c) 2016-2017 Aladdin */
'use strict';

function Clipboard(aladdin) {
  this._aladdin = aladdin;
}

Object.defineProperty(Clipboard.prototype, 'name', {
  value: 'clipboard',
  writable: false
});

/**
 * 复制文本到剪切板 
 *
 * @param {Object} opts
 * @property {String} copyStr 复制字段名称
 * @param {Function} cb
 */
Clipboard.prototype.copy = function(opts, cb) {
  opts = opts || {};

  return this._aladdin.call(this.name, 'copy', opts, cb);
};

/**
 * 清除剪切板
 *
 * @param {Function} cb
 */
Clipboard.prototype.clear = function(cb) {
  return this._aladdin.call(this.name, 'clear', cb);
};

module.exports = Clipboard;
