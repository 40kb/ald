package com.aladdin.component.aldbrowsercomponent;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.pingan.aladdin.core.Debuger;

/**
 * Created by ouyangxingyu198 on 16/7/25.
 */
public class BrowserHelper {

    /**
     * 打开系统浏览器
     * @param context
     * @param url
     */
    public static void open(Context context,String url) throws Exception{
        try{
            context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }catch (Exception e){
            Debuger.logD(e.getMessage());
        }
    }
}
