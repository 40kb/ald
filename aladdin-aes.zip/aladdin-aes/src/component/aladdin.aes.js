'use strict';
// import aladdin from 'aladdin';

/**
 *
 * @constructor
 * @param {object} adapter
 */
function Aes(aladdin) {
  this._aladdin = aladdin;
}

Object.defineProperty(Aes.prototype, 'name', {
  value: 'aes',
  writable: false
});

/**
 * aes加密
 * @param {Object} opts
 * @param {Function} cb
 */
Aes.prototype.encrypt = function(opts, cb) {
  opts = opts || {};
  return this._aladdin.call(this.name, 'encrypt', opts, cb);
};

/**
 * aes解密
 * @param {Object} opts
 * @param {Function} cb
 */
Aes.prototype.decrypt = function(opts, cb) {
  opts = opts || {};
  return this._aladdin.call(this.name, 'decrypt', opts, cb);
};

// aladdin.use(Aes, 'aes');
export default Aes;