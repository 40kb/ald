/*! aladdin.audio v1.0.0 (c) 2016-2017 Aladdin */
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('aladdin')) :
	typeof define === 'function' && define.amd ? define(['aladdin'], factory) :
	(global.aladdin = global.aladdin || {}, global.aladdin.audio = factory(global.aladdin));
}(this, (function (aladdin) { 'use strict';

function __$styleInject(css, returnValue) {
  if (typeof document === 'undefined') {
    return returnValue;
  }
  css = css || '';
  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';
  if (style.styleSheet){
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
  head.appendChild(style);
  return returnValue;
}

aladdin = 'default' in aladdin ? aladdin['default'] : aladdin;

function Audio() {}

Object.defineProperty(Audio.prototype, 'name', {
  value: 'audio',
  writable: false
});

/**
 * 音频播放开始
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Audio.prototype.play = function(opts, cb) {

  opts = opts || {};
  cb = typeof cb === 'function' ? cb : function() {};

  var audioElem = this.audioElem;
  if (typeof opts.fileName !== 'string') { //播放路径不存在
    if (audioElem) {
      opts.fileName = audioElem.src;
    } else {
      cb({
        code: '' //播放地址不存在
      });
      return this;
    }
  }

  /**
   * 已经存在,播放文件是同一个,则认为是继续播放
   */
  if (audioElem && audioElem.src == opts.fileName) {
    audioElem.play();
  } else {
    audioElem && this.stop();

    audioElem = this.audioElem = document.createElement('audio');
    audioElem.src = opts.fileName;
    audioElem.play();
  }

  audioElem.onplaying = function() {
    audioElem.onplaying = null;
    cb();
  };
  audioElem.onerror = function() {
    audioElem.onerror = null;
    cb({
      code: '' //播放地址不存在
    });
  };
  return this;
};

/**
 * 音频播放停止
 *
 * @param {Function} cb
 */
Audio.prototype.stop = function(cb) {
  cb = typeof cb === 'function' ? cb : function() {};

  var audioElem = this.audioElem;
  if (audioElem) {
    audioElem.pause();
    audioElem.onerror = null; //资源src置空后会报错，不执行回调
    audioElem.onplaying = null;
    audioElem.src = '';

    cb();
  } else {
    cb({
      code: ''
    });
  }


  return this;
};

/**
 * 音频播放暂停
 *
 * @param {Function} cb
 */
Audio.prototype.pause = function(cb) {
  cb = typeof cb === 'function' ? cb : function() {};

  var audioElem = this.audioElem;
  if (!audioElem) {
    cb({
      code: ''
    });
    return;
  }

  audioElem.onpause = function() {
    audioElem.onpause = null;
    cb();
  };
  audioElem.onerror = function() {
    audioElem.onerror = null;
    cb({
      code: ''
    });
  };
  audioElem.pause();

  return this;
};

aladdin.use(Audio);

var index_web = aladdin.audio;

return index_web;

})));
