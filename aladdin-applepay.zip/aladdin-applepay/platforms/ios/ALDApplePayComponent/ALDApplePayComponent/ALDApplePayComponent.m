//
//  PAEBOpenWallet.m
//  PAEBank
//
//  Created by insigmaMAC on 2017/4/6.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import "ALDApplePayComponent.h"
#import <UIKit/UIKit.h>

@implementation ALDApplePayComponent
ALD_Custom_Module(applepay);

-(void)openWallet:(ALDJSWebView*)webView :(NSString*)callBack{
    if([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2)
    {
        NSURL *url = [NSURL URLWithString:@"shoebox://"];
        dispatch_async(dispatch_get_main_queue(), ^{
            if([[UIApplication sharedApplication] canOpenURL:url])
            {
                BOOL isSuccess = [[UIApplication sharedApplication] openURL:url];
                [webView callBack_Json:callBack params:@[[NSNumber numberWithBool:isSuccess]] err:nil];
            }
        });
    }
    else
    {
        [webView callBack_Json:callBack params:@[@NO] err:nil];
    }
    
    
}
@end
