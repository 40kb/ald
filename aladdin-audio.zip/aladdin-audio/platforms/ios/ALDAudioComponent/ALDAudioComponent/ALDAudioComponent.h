//
//  PABowAudioPlugin.h
//  PAiPhoneBank3.0
//
//  Created by xie on 16/10/31.
//  Copyright © 2016年 熊剑明. All rights reserved.
//

#import <AladdinHybrid/AladdinHybrid.h>

@interface ALDAudioComponent : ALDHybridBridge

/**
 *  音频播放开始
 *
 *  @param webView  <#webView description#>
 *  @param jsonStr  <#jsonStr description#>
 *  @param callBack <#callBack description#>
 */
-(void)play:(ALDJSWebView*)webView :(NSString*)jsonStr :(NSString*)callBack;

/**
 *  音频播放停止
 *
 *  @param webView  <#webView description#>
 *  @param jsonStr  <#jsonStr description#>
 *  @param callBack <#callBack description#>
 */
-(void)stop:(ALDJSWebView*)webView :(NSString*)callBack;


/**
 *  音频播放暂停
 *
 *  @param webView  <#webView description#>
 *  @param jsonStr  <#jsonStr description#>
 *  @param callBack <#callBack description#>
 */
-(void)pause:(ALDJSWebView*)webView :(NSString*)callBack;


@end
