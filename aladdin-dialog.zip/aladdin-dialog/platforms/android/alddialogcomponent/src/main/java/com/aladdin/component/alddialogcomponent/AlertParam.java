package com.aladdin.component.alddialogcomponent;

/**
 * Created by ouyangxingyu198 on 16/7/19.
 */
public class AlertParam {

    private String title;
    private String message;
    private String buttonText;
    private String buttonCallback;

    @Override
    public String toString() {
        return "AlertParam{" +
                "title='" + title + '\'' +
                ", onMessage='" + message + '\'' +
                ", buttonText='" + buttonText + '\'' +
                ", buttonCallback='" + buttonCallback + '\'' +
                '}';
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getButtonText() {
        return buttonText;
    }

    public void setButtonText(String buttonText) {
        this.buttonText = buttonText;
    }

    public String getButtonCallback() {
        return buttonCallback;
    }

    public void setButtonCallback(String buttonCallback) {
        this.buttonCallback = buttonCallback;
    }
}
