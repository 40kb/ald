package com.aladdin.component.aldgeolocatinoncomponent;

import android.content.Context;
import android.location.LocationManager;


import com.pingan.aladdin.core.Debuger;

import org.json.JSONObject;


/**
 * @author ex-yangzhenxing001@pingan.com.cn
 * @date 2016/9/12
 */
public class BaiduLocationManager{
    //    public LocationClient mLocationClient = null;
    static BaiduLocationManager instance = null;
    static Context mContext = null;
    private final String tag = "BaiduLocationManager";
    private LocationCallback mCallback = null;
    // 是否需要地址信息
    private boolean isNeedAddr = true;

    private BaiduLocationManager(Context context) {
       /* mLocationClient = new LocationClient(context);
        setLocationOption();
        mLocationClient.registerLocationListener(myListener);*/

    }

    /**
     * 定位监听
     **/
//    private MyLocationListenner myListener = new MyLocationListenner();

    public static BaiduLocationManager getInstance(Context context) {
        mContext = context.getApplicationContext();
        if (null == instance) {
            synchronized (BaiduLocationManager.class) {
                if (null == instance) {
                    instance = new BaiduLocationManager(mContext);
                }
            }
        }
        return instance;
    }

    public void requestLocation(int timeOutDelay, LocationCallback callback) {
        /*if (timeOutDelay > 1000) {
            mLocationClient.stop();
            mLocationClient.getLocOption().setTimeOut(timeOutDelay);
        }
        this.mCallback = callback;
        if (isGPSEnabled()) {
            mLocationClient.getLocOption().setOpenGps(true);
            mLocationClient.getLocOption().setPriority(LocationClientOption.GpsFirst);
        } else {
            mLocationClient.getLocOption().setPriority(LocationClientOption.NetWorkFirst);
        }
        mLocationClient.start();*/

    }

    /**
     * 设置相关参数
     */
    private void setLocationOption() {
/*
        LocationClientOption option = new LocationClientOption();
        option.setCoorType("gcj02");            //设置坐标类型
        option.setScanSpan(0);                //设置定位模式，小于1秒则一次定位;大于等于1秒则定时定位  设置为1小时，201604需求 by ex-xuyuan001
        option.disableCache(false);            //true表示禁用缓存定位，false表示启用缓存定位
        option.setIsNeedAddress(isNeedAddr);// 可选，设置是否需要地址信息，默认不需要
        option.setTimeOut(10);
        option.setIsNeedLocationDescribe(true);// 可选，默认false，设置是否需要位置语义化结果，可以在BDLocation.getLocationDescribe里得到，结果类似于“在北京天安门附近”
        option.setIsNeedLocationPoiList(true);// 可选，默认false，设置是否需要POI结果，可以在BDLocation.getPoiList里得到

        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy);// 可选，默认高精度，设置定位模式，高精度，低功耗，仅设备
        if (isGPSEnabled()) {
            option.setOpenGps(true);
            option.setPriority(LocationClientOption.GpsFirst);
        } else {
            option.setPriority(LocationClientOption.NetWorkFirst);
        }

        mLocationClient.setLocOption(option);*/
    }

    public boolean isGPSEnabled() {
        try {
            LocationManager locManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
            if (null == locManager) {
                return false;
            } else {
                return locManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            }

        } catch (Exception e) {
            Debuger.logD(e.getMessage());
        }
        return false;
    }

    /**
     * 监听函数
     */
    /*private class MyLocationListenner implements BDLocationListener {

        @Override
        public void onReceiveLocation(BDLocation location) {
            Debuger.logE(tag, "获取地理位置1:onReceiveLocation ");
            if (location == null) return;

//			返回值：
//			61 ： GPS定位结果
//			62 ： 扫描整合定位依据失败。此时定位结果无效。
//			63 ： 网络异常，没有成功向服务器发起请求。此时定位结果无效。
//			65 ： 定位缓存的结果。
//			66 ： 离线定位结果。通过requestOfflineLocaiton调用时对应的返回结果
//			67 ： 离线定位失败。通过requestOfflineLocaiton调用时对应的返回结果
//			68 ： 网络连接失败时，查找本地离线定位时对应的返回结果
//			161： 表示网络定位结果
//			162~167： 服务端定位失败。
            Debuger.logE(tag, location.getLocType() + location.getLocationDescribe());
            switch (location.getLocType()) {
                case 61:
                case 65:
                case 66:
                case 68:
                case 161:
                    double locationLatitude = location.getLatitude();
                    double locationLongitude = location.getLongitude();
                    StringBuilder builder = new StringBuilder();
                    if (location.getPoiList() != null && !location.getPoiList().isEmpty()) {
                        for (int i = 0; i < location.getPoiList().size(); i++) {
                            Poi poi = location.getPoiList().get(i);
                            builder.append(poi.getName() + ",");
                        }
                    }

                    if (mCallback != null) {
                        try {
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put(LocationParams.LATITUDE, locationLatitude);
                            jsonObject.put(LocationParams.LONGITUDE, locationLongitude);
                            jsonObject.put(LocationParams.POI, builder.toString());
                            jsonObject.put(LocationParams.ADDR, location.getAddrStr());
                            mCallback.onSucceedCallback(jsonObject);
                        } catch (JSONException e) {
                            // TODO Auto-generated catch block
                            Debuger.logD(e.getMessage());
                            JSONObject err = null;
                            try {
                                err = new JSONObject(e.getMessage());
                            } catch (JSONException e1) {
                                e1.printStackTrace();
                            }
                            mCallback.onErrorCallback(err);
                        }
                    }
                    break;
                default:
                    if (null != mCallback) {
                        JSONObject object = new JSONObject();
                        try {
                            object.put("errCode", location.getLocType());
                        } catch (JSONException e) {
                            Debuger.logD(e.getMessage());
                        }
                        mCallback.onErrorCallback(object);
                    }
            }
            //GPS信息写入数据库
            putGPSTodb(location);
        }

    }*/

    public interface LocationCallback {
        /**
         * 失败回调
         *
         * @param errorInfo
         */
        void onErrorCallback(JSONObject errorInfo);

        /**
         * 成功回调
         *
         * @param succedInfo
         */
        void onSucceedCallback(JSONObject succedInfo);

    }

    /*
     * talkingData 对地理位置的记载
	 */
   /* public void putGPSTodb(BDLocation location) {

        GPSLocation gPSLocation = new GPSLocation();
        gPSLocation.setTime(location.getTime());
        gPSLocation.setAltitude(location.getAltitude());
        gPSLocation.setLatitude(location.getLatitude());
        gPSLocation.setLongitude(location.getLongitude());

        PADataAgent.onGPSLocation(gPSLocation);

    }*/
}
