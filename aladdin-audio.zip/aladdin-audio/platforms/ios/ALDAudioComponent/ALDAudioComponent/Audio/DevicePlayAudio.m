//
//  DevicePlayAudio.m
//  PAiPhoneBank3.0
//
//  Created by 李想 on 16/9/29.
//  Copyright © 2016年 熊剑明. All rights reserved.
//

#import "DevicePlayAudio.h"
#import <AVFoundation/AVFoundation.h>

@interface DevicePlayAudio()
{
    BOOL _isPause;
    BOOL _isStop;
}
@property (strong, nonatomic) AVPlayer *player;
@end

@implementation DevicePlayAudio

+(instancetype)sharePlayAudio{
    
        static DevicePlayAudio* _playAudio = nil;
        static dispatch_once_t onceToken ;
    
        dispatch_once(&onceToken, ^{
            _playAudio = [[self alloc] init] ;
        }) ;
        
        return _playAudio ;

}

-(void)playMusic:(NSString*)musicName {
    //可播放可录音，更可以后台播放，还可以在其他程序播放的情况下暂停播放
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setCategory:AVAudioSessionCategoryPlayAndRecord
             withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker
                   error:nil];
    _isStop = NO;
    if (_isPause) {
//        [self.player prepareToPlay];
        [self.player play];
        _isPause = NO;
        return;
    }
    NSURL *url = nil;
    if ([musicName hasPrefix:@"http"]) {
        self.player = [[AVPlayer alloc] initWithURL:[NSURL URLWithString:musicName]];
    }else{
        url = [[NSBundle mainBundle] URLForResource:musicName withExtension:nil];
        self.player = [[AVPlayer alloc] initWithURL:url];
    }
    // 只读属性, 一个Player只能播放对应的一首歌曲
    [self.player play];
}

- (void)stop
{
    _isPause = NO;
    _isStop = YES;
    self.player = nil;
}

- (void)pause {
    _isPause = _isStop?NO:YES;
    [self.player pause];
}




@end
