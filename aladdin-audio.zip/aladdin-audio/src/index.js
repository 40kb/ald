import aladdin from 'aladdin';
import Audio from './component/aladdin.audio';

aladdin.use(Audio);

export default aladdin.audio;