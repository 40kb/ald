/*! aladdin.dialog v1.0.0 (c) 2016-2017 Aladdin */
'use strict';

function __$styleInject(css, returnValue) {
  if (typeof document === 'undefined') {
    return returnValue;
  }
  css = css || '';
  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';
  if (style.styleSheet){
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
  head.appendChild(style);
  return returnValue;
}

__$styleInject(".aladdin-dialog {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  z-index: 9999;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  background: rgba(0, 0, 0, .4);\n}\n\n.aladdin-dialog-content {\n  border-radius: 6px;\n  width: 270px;\n  background-clip: padding-box;\n  pointer-events: auto;\n  background-color: rgba(253, 253, 253, .95);\n  position: relative;\n  font-size: 16px;\n}\n\n.aladdin-dialog-header {\n  height: 48px;\n  line-height: 48px;\n  text-align: center;\n  position: relative;\n  border-bottom: 1px solid #ded8d8;\n}\n\n.aladdin-dialog-body {\n  min-height: 40px;\n  border-top-left-radius: 6px;\n  border-top-right-radius: 6px;\n  border-bottom: 1px solid #ded8d8;\n  padding: 18px;\n  /*display: -webkit-box;\n  display: box;\n  -webkit-box-pack: center;\n  -webkit-box-align: center;\n  -webkit-box-orient: vertical;*/\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n\n.aladdin-dialog-body>div {\n  width: 100%;\n  text-align: center;\n}\n\n.aladdin-dialog-footer {\n  height: 42px;\n  line-height: 42px;\n  border-bottom-left-radius: 6px;\n  border-bottom-right-radius: 6px;\n  width: 100%;\n}\n\n.aladdin-dialog-footer-btn {\n  color: #00a5e0;\n  text-align: center;\n  width: 100%;\n  line-height: 42px;\n  text-align: center;\n  display: inline-block;\n}\n\n.aladdin-dialog-footer-left {\n  width: 49%;\n  border-right: 1px solid #ded8d8;\n}\n\n.aladdin-dialog-footer-right {\n  width: 49%;\n}",undefined);

function Dialog(aladdin) {
  this._aladdin = aladdin;

}

Dialog.prototype._fixScale = function() {
  if (this._fixed) {
    return;
  }
  this._fixed = true;
  var metaEl = document.querySelector('meta[name="viewport"]');
  if (metaEl) {
    var match = metaEl.getAttribute('content').match(/initial\-scale=([\d\.]+)/);
    if (match) {
      var scale = parseFloat(match[1]);
      var dpr = parseFloat(1 / scale);
      var transformStyles = [];
      var transformPropertys = ['transform', '-webkit-transform', '-moz-transform', '-o-transform'];
      for (var i = 0; i < transformPropertys.length; i++) {
        transformStyles.push(transformPropertys[i] + ':scale(' + dpr + ',' + dpr + ');');
      }
      this._injectStyle('.aladdin-dialog-content{'+transformStyles.join('')+'}');
      //this._injectStyle('.aladdin-dialog-content{transform: scale(' + dpr + ',' + dpr + ');}');
    }
  }
};
Object.defineProperty(Dialog.prototype, 'name', {
  value: 'dialog',
  writable: false
});

Dialog.prototype._injectStyle = function(css, returnValue) {
  if (typeof document === 'undefined') {
    return returnValue;
  }
  css = css || '';
  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';
  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
  head.appendChild(style);
  return returnValue;
};

Dialog.prototype.alert = function(opts, cb) {
  typeof cb === 'function' || (cb = function() {});
  if (typeof opts !== 'object') {
    throw new Error('Loading 第一个参数需要是对象');
  }
  this._fixScale();
  var alertElems = document.getElementsByClassName('aladdin-dialog');
  for (var i = 0; i < alertElems.length; i++) {
    alertElems[i].remove();
  }

  var title = opts.title || '提示';
  var message = opts.message || '';
  var buttonText = opts.buttonText || '确定';
  var buttonCallback = opts.buttonCallback || function() {};
  var alertHtml = '<div class="aladdin-dialog">' +
    '<div class="aladdin-dialog-content">' +
    '<div class="aladdin-dialog-header">' + title + '</div>' +
    '<div class="aladdin-dialog-body"><div>' + message + '</div></div>' +
    '<div class="aladdin-dialog-footer">' +
    '<span class="aladdin-dialog-footer-btn">' + buttonText + '</span>' +
    '</div></div></div>';

  var alertElem = document.createElement('div');
  alertElem.className = 'aladdin-dialog';
  alertElem.innerHTML = alertHtml;
  document.body.appendChild(alertElem);

  var btnElem = alertElem.getElementsByClassName('aladdin-dialog-footer-btn')[0];
  btnElem.addEventListener('click', function() {
    buttonCallback();
    alertElem.remove();
  });

  cb();
  return this;
};

Dialog.prototype.confirm = function(opts, cb) {
  typeof cb === 'function' || (cb = function() {});
  if (typeof opts !== 'object') {
    throw new Error('第一个参数需要是对象');
  }
  this._fixScale();
  var confirmElems = document.getElementsByClassName('aladdin-dialog');
  for (var i = 0; i < confirmElems.length; i++) {
    confirmElems[i].remove();
  }

  var title = opts.title || '提示';
  var message = opts.message || '请选择';
  var leftButtonText = opts.leftButtonText || '取消';
  var leftButtonCallback = opts.leftButtonCallback || function() {};
  var rightButtonText = opts.rightButtonText || '确定';
  var rightButtonCallback = opts.rightButtonCallback || function() {};

  var confirmEle = document.getElementById("aladdin-confirm");
  if (confirmEle && confirmEle.length > 0) {
    confirmEle.remove();
  }
  var confirmHtml = '<div class="aladdin-dialog">' +
    '<div class="aladdin-dialog-content">' +
    '<div class="aladdin-dialog-header">' + title + '</div>' +
    '<div class="aladdin-dialog-body"><div>' + message + '</div></div>' +
    '<div class="aladdin-dialog-footer">' +
    '<span class="aladdin-dialog-footer-btn aladdin-dialog-footer-left">' + leftButtonText + '</span>' +
    '<span class="aladdin-dialog-footer-btn aladdin-dialog-footer-right">' + rightButtonText + '</span>' +
    '</div></div></div>';

  var confirmElem = document.createElement('div');
  confirmElem.className = 'aladdin-dialog';
  confirmElem.innerHTML = confirmHtml;
  document.body.appendChild(confirmElem);

  var leftBtnElem = confirmElem.getElementsByClassName('aladdin-dialog-footer-left')[0];
  leftBtnElem.addEventListener('click', function() {
    if (typeof leftButtonCallback === 'function') {
      leftButtonCallback();
    }
    confirmElem.remove();
  });

  var rightBtnElem = confirmElem.getElementsByClassName('aladdin-dialog-footer-right')[0];
  rightBtnElem.addEventListener('click', function() {
    if (typeof rightButtonCallback === 'function') {
      rightButtonCallback();
    }
    confirmElem.remove();
  });

  cb();

  return this;
};

module.exports = Dialog;
