'use strict';

import aladdin from 'aladdin';
import Clipboard from './component/aladdin.clipboard';

aladdin.use(Clipboard);

export default aladdin.clipboard;