package com.aladdin.component.aldcameracomponent.chooseMorePic.click;

import android.view.View;

public interface OnItemClickListener {
    void onItemClickListener(View view, int position);
}
