const fs = require('fs');
const rollup = require('rollup');
const uglify = require('uglify-js');
const uglifycss = require('uglifycss');
const buble = require('rollup-plugin-buble');
const replace = require('rollup-plugin-replace');
const postcss = require('rollup-plugin-postcss');
const autoprefixer = require('autoprefixer');
const ora = require('ora');
const path = require('path');
let {
    name,
    version
} = require('./package.json');

name = name.replace(/^aladdin-/, '');

const distDir = path.resolve(__dirname, './dist');
const srcDir = __dirname + '/src';

const banner = '/*! aladdin.' + name + ' v' + version + ' (c) 2016-' + new Date().getFullYear() + ' Aladdin */';
const format = 'umd';

const spinner = ora('building...').start();

Promise.all([
    packaging(srcDir + '/index.js', 'aladdin.' + name, false),
    packaging(srcDir + '/index.web.js', 'aladdin.' + name + '.web', false),
    packaging(srcDir + '/component/aladdin.' + name + '.js', 'aladdin.' + name + '.common', false, 'cjs'),
    packaging(srcDir + '/component/aladdin.' + name + '.web.js', 'aladdin.' + name + '.web.common', true, 'cjs')
])
    .catch(function(err) {
        spinner.fail(JSON.stringify(err));
    });

function packaging(entry, output, usePostcss, format) {
    format = format || 'umd';
    return rollup.rollup({
        entry: entry,
        external: ['aladdin'],
        plugins: [
            usePostcss && postcss({
                plugins: [autoprefixer({
                    browsers: ['> 1%', 'last 2 versions', 'ie 6-8'],
                    remove: false
                })],
                extensions: ['.css']
            }),
            buble()
        ]
    })
        .then(function(bundle) {
            const code = bundle.generate({
                format: format,
                banner: banner,
                moduleName: 'aladdin.' + name,
                external: ['aladdin'],
                globals: {
                    aladdin: 'aladdin'
                }
            }).code;

            if (format !== 'cjs') {
                const res = uglify.minify(code, {
                    fromString: true,
                    output: {
                        preamble: banner,
                        ascii_only: true
                    }
                });
                return [
                    write(path.join(distDir, output + '.js'), code),
                    write(path.join(distDir, output + '.min.js'), res.code),
                ];
            } else {
                write(path.join(distDir, output + '.js'), code)
            }
        });
}

function write(dist, code) {
    return new Promise(function(resolve, reject) {
        fs.writeFile(dist, code, function(err) {
            if (err) return reject(err);
            spinner.succeed(blue(dist) + ' ' + getSize(code));
            resolve();
        });
    });
}

function getSize(code) {
    return (code.length / 1024).toFixed(2) + 'kb';
}

function onerror(e) {
    console.log(e);
}

function blue(str) {
    return '\x1b[1m\x1b[34m' + str + '\x1b[39m\x1b[22m';
}