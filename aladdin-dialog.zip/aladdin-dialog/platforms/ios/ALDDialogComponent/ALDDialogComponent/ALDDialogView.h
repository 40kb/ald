//
//  Dialog.h
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/15.
//  Copyright © 2016年 WQ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**< 取消 */
typedef void(^AlertCancelBlock)();

/**< 确定回调 */
typedef void(^AlertEnterBlock)();

/**
 *  错误回调
 *
 *  @param errorMessage 错误信息
 */
typedef void(^ShowAlertErrorBlock)(NSDictionary *errorMessage);

@interface ALDDialogView : NSObject


+(ALDDialogView *)shareDialog;


/**
 *  @brief             alert
 *
 *  @param type        弹框类型：alert
 *  @param title       标题
 *  @param message     内容
 *  @param buttonTitle 按钮标题
 *  @param enterBlock  按钮点击回调
 */
- (void)alertWithType:(NSString *)type Title:(NSString *)title Message:(NSString *)message ButtonTitle:(NSString *)buttonTitle EnterCallBack:(AlertEnterBlock)enterBlock;

/**
 *  @brief                          confirm
 *
 *  @param type                     弹框类型: confirm
 *  @param title                    标题
 *  @param message                  neir
 *  @param leftButtonTitle          左按钮标题
 *  @param leftButtonCallBackBlock  左按钮回调
 *  @param rightButtonTitle         右按钮标题
 *  @param rightButtonCallBackBlock 右按钮回调
 */
- (void)confirmWithType:(NSString *)type Title:(NSString *)title Message:(NSString *)message LeftButtonTitle:(NSString *)leftButtonTitle LeftButtonCallBackBlock:(AlertEnterBlock)leftButtonCallBackBlock RightButtonTitle:(NSString *)rightButtonTitle RightButtonCallBackBlock:(AlertCancelBlock)rightButtonCallBackBlock;



@end
