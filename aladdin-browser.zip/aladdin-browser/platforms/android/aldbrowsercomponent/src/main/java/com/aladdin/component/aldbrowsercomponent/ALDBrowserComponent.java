package com.aladdin.component.aldbrowsercomponent;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;

import com.pingan.aladdin.core.Debuger;
import com.pingan.aladdin.core.exception.errorManager.AladdinErrorMessage;
import com.pingan.aladdin.core.exception.errorManager.ErrorCode;
import com.pingan.aladdin.core.resource.metaData.ResourceMetaDataMananger;
import com.pingan.aladdin.h5.webview.AladdinWebView;
import com.pingan.aladdin.h5.webview.plugin.AladdinJSExecutor;
import com.pingan.aladdin.h5.webview.plugin.HybridComponent;

import org.json.JSONObject;


/**
 * Created by ouyangxingyu198 on 16/7/25.
 */
public class ALDBrowserComponent extends HybridComponent {

    private static Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public String getName() {
        return "browser";
    }

    @Override
    public boolean isActivityCallbackEnable() {
        return false;
    }

    @JavascriptInterface
    public void open(final AladdinWebView webView, JSONObject jsonObject, final String callback) {
//        final BrowserParam browserParam = (BrowserParam) JSJsonParamParser.getResult(jsonObject, BrowserParam.class);
        final BrowserParam browserParam = (BrowserParam) ResourceMetaDataMananger.getResult(jsonObject, BrowserParam.class);
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (browserParam == null || TextUtils.isEmpty(browserParam.getUrl())) {
                    try {
                        AladdinJSExecutor.callStringToJS(webView, callback, null, AladdinErrorMessage.build(110014,"url参数异常,不能为空"));
                    }catch (Exception e){
                        Debuger.logD(e.getMessage());
                    }

                    return;
                }
                try {
                   BrowserHelper.open(getContext(webView), browserParam.getUrl());
                } catch (Exception e) {
                    Debuger.logD(e.getMessage());
                    try {
                        AladdinJSExecutor.callStringToJS(webView, callback, null, AladdinErrorMessage.build(ErrorCode.UNKWON_ERROR));
                    }catch (Exception e1){
                        Debuger.logD(e.getMessage());
                    }
                }
            }
        });
    }
}
