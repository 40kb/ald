function Geolocation(aladdin) {
  this._aladdin = aladdin;
}
Object.defineProperty(Geolocation.prototype, 'name', {
  value: 'geolocation',
  writable: false
});

Geolocation.prototype.getCurrentPosition = function(cb) {
  this._aladdin.call(this.name, 'getCurrentPosition', cb);
  return this;
};


export default Geolocation;