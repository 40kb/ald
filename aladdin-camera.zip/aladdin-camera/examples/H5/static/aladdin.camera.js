/*! aladdin.camera v1.0.0 (c) 2016-2018 Aladdin */
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('aladdin')) :
	typeof define === 'function' && define.amd ? define(['aladdin'], factory) :
	(global.aladdin = global.aladdin || {}, global.aladdin.camera = factory(global.aladdin));
}(this, (function (aladdin) { 'use strict';

aladdin = 'default' in aladdin ? aladdin['default'] : aladdin;

function Camera(aladdin$$1) {
  this._aladdin = aladdin$$1;
}

Object.defineProperty(Camera.prototype, 'name', {
  value: 'camera',
  writable: false
});

/**
 * 获取照片
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Camera.prototype.getPhotos = function(opts, cb) {
  opts = opts || {};

  this._aladdin.call(this.name, 'getPhotos', opts, cb);

  return this;
};

/**
 * 检测前置摄像头是否开启
 * （安卓需检测是否可用）
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Camera.prototype.getFrontCameraState = function(cb) {
  this._aladdin.call(this.name, 'getFrontCameraState', cb);
  return this;
};

aladdin.use(Camera);

var index = aladdin.camera;

return index;

})));
