/**
 * 校验必须为指定类型且有值的参数
 *
 * @param {any} name 参数名称
 * @param {any} val 参数值
 * @param {any} type 参数类型
 */
export function required(name, val, type = 'string') {
  if (val === undefined || typeof val !== type) {
    throw new TypeError(`The ${name} must be a ${type} and a value`);
  }
}

export function info(message) {
  throw new Error(message);
}
