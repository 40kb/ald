//
//  ALDDialog.h
//  ALADINModuleDemo
//
//  Created by WQ on 16/7/18.
//  Copyright © 2016年 WQ. All rights reserved.
//
#import <AladdinHybrid/AladdinHybrid.h>
@interface ALDDialogComponent : ALDHybridBridge


/**
 *  @brief                       alert
 *
 *  @param webView               ALDJSWebView
 *  @param jsonString            opts对象
 *         opts.title            显示的标题
 *         opts.message	         显示的消息
 *         opts.buttonText       按钮显示文本，默认为确定
 *         opts.buttonCallback   按钮回调方法
 *  @param callBack              错误回调
 */
-(void)alert:(ALDJSWebView *)webView :(NSString *)jsonString :(NSString *)callBack;

/**
 *  @brief                              confirm
 *
 *  @param webView                      ALDJSWebView
 *  @param jsonString                   opts对象
 *         opts.title                   显示的标题
 *         opts.message  	            显示的消息
 *         opts.leftButtonText          左侧按钮显示文本，默认为取消
 *         opts.leftButtonCallback      左侧按钮回调方法
 *         opts.rightButtonText         右侧按钮显示文本，默认为确定
 *         opts.rightButtonCallback     右侧按钮回调方法
 *  @param callBack                     错误回调
 */
-(void)confirm:(ALDJSWebView *)webView :(NSString *)jsonString :(NSString *)callBack;
@end
