//
//  ALDAESCipher.h
//  ALDAESComponent
//
//  Created by xiangyutao on 2017/6/7.
//  Copyright © 2017年 xiangyutao. All rights reserved.
//

#import <Foundation/Foundation.h>

NSString * aesEncryptString(NSString *content, NSString *key,size_t kKeySize);
NSString * aesDecryptString(NSString *content, NSString *key,size_t kKeySize);

NSData * aesEncryptData(NSData *data, NSData *key,size_t kKeySize);
NSData * aesDecryptData(NSData *data, NSData *key,size_t kKeySize);
