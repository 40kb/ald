'use strict';

function Browser(aladdin) {

}

Object.defineProperty(Browser.prototype, 'name', {
    value: 'browser',
    writable: false
});

Browser.prototype.open = function (opts, cb) {
  typeof cb === 'function' && cb();
  var features = "toolbar=no, location=yes, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width=510, height=750";
  window.open(opts.url,"_blank",features);
  return this;
};

export default Browser;

