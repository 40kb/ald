'use strict';

/**
 *
 * @constructor
 * @param {object} adapter
 */
function Applepay(aladdin) {
  this._aladdin = aladdin;
}

Object.defineProperty(Applepay.prototype, 'name', {
  value: 'applepay',
  writable: false
});

/**
 * 打开钱包
 * @param {Function} cb
 */
Applepay.prototype.openWallet = function(cb) {
  return this._aladdin.call(this.name, 'openWallet', cb);
};

export default Applepay;