'use strict';
import aladdin from 'aladdin';
import Applepay from './component/aladdin.applepay';
aladdin.use(Applepay);
export default aladdin.applepay;