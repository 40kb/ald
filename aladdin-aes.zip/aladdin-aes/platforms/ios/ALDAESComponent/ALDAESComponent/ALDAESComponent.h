//
//  ALDAESComponent.h
//  ALDAESComponent
//
//  Created by xiangyutao on 2017/6/6.
//  Copyright © 2017年 xiangyutao. All rights reserved.
//

#import <AladdinHybrid/AladdinHybrid.h>

@interface ALDAESComponent : ALDHybridBridge


#warning AES加密暂时只支持AES128 padding:PKCS7Padding mode:ECBMODE

/**
 AES加密
 
 @param webView         jswebview实例化对象
 @param jsonStr          opts对象
 *      opts.text  	     需加密字段
 *      opts.key         密钥
 *      opts.size        密钥长度(位数)
 *      opts.iv          初始化向量
 *      opts.mode        加密模式
 *      opts.padding     填充方式
 
 @param callBack  回调参数
 */
-(void)encrypt:(ALDJSWebView*)webView :(NSString *)jsonStr :(NSString*)callBack;


/**
 AES解密
 
 @param webView         jswebview实例化对象
 @param jsonStr          opts对象
 *      opts.text  	     需解密字段
 *      opts.key         密钥
 *      opts.size        密钥长度(位数)
 *      opts.iv          初始化向量
 *      opts.mode        加密模式
 *      opts.padding     填充方式
 
 @param callBack  回调参数
 */
-(void)decrypt:(ALDJSWebView*)webView :(NSString *)jsonStr :(NSString*)callBack;




@end
