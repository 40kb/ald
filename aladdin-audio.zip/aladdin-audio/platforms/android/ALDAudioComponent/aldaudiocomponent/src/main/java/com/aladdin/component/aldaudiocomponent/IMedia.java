package com.aladdin.component.aldaudiocomponent;

/**
 * Created by nijinlei on 16/11/14.
 */

public interface IMedia {
    void mediaPlay(String url);

    void mediaStop();

    void mediaPause();
}
