'use strict';

function Audio(aladdin) {
  this._aladdin = aladdin;
}

Object.defineProperty(Audio.prototype, 'name', {
  value: 'audio',
  writable: false
});

/**
 * 音频播放开始
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Audio.prototype.play = function(opts, cb) {
  opts = opts || {};

  return this._aladdin.call(this.name, 'play', opts, cb);
};

/**
 * 音频播放停止
 *
 * @param {Function} cb
 */
Audio.prototype.stop = function(cb) {
  return this._aladdin.call(this.name, 'stop', cb);
};

/**
 * 音频播放暂停
 *
 * @param {Function} cb
 */
Audio.prototype.pause = function(cb) {
  return this._aladdin.call(this.name, 'pause', cb);
};

export default Audio;