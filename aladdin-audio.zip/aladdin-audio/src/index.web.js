import aladdin from 'aladdin';
import Audio from './component/aladdin.audio.web';

aladdin.use(Audio);

export default aladdin.audio;