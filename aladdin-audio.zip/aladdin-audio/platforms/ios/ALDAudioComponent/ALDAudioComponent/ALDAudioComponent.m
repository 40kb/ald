//
//  PABowAudioPlugin.m
//  PAiPhoneBank3.0
//
//  Created by xie on 16/10/31.
//  Copyright © 2016年 熊剑明. All rights reserved.
//

#import "ALDAudioComponent.h"
#import "DevicePlayAudio.h"

@implementation ALDAudioComponent
ALD_Custom_Module(Audio);

//音频播放开始
- (void)play:(ALDJSWebView *)webView :(NSString *)jsonStr :(NSString *)callBack
{
    NSDictionary *jsonDic = [jsonStr objectFromJSONString];
    NSString *fileName = [jsonDic objectForKey:@"fileName"];
    if (!fileName) {
        [webView callBack_Json:callBack params:nil err:[ALDError standardError:ALDErrorType_Data_Exception]];
        return;
    }
    [[DevicePlayAudio sharePlayAudio] playMusic:fileName];
    [webView callBack_Json:callBack params:nil err:nil];
    
}


//音频播放停止
- (void)stop:(ALDJSWebView *)webView :(NSString *)callBack
{
    [[DevicePlayAudio sharePlayAudio] stop];
    [webView callBack_Json:callBack params:nil err:nil];
}


//音频播放暂停
- (void)pause:(ALDJSWebView *)webView :(NSString *)callBack
{
    [[DevicePlayAudio sharePlayAudio] pause];
    [webView callBack_Json:callBack params:nil err:nil];
}

@end
