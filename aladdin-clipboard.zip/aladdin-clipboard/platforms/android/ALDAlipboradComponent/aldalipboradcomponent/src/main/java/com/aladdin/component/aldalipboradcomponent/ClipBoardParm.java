package com.aladdin.component.aldalipboradcomponent;

/**
 * Created by as-ipone on 17/5/16.
 */

public class ClipBoardParm {
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
