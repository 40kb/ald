'use strict';

function Browser(aladdin) {
  this._aladdin = aladdin;
}

Object.defineProperty(Browser.prototype, 'name', {
    value: 'browser',
    writable: false
});

/**
 * 调起浏览器打开网页
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Browser.prototype.open = function (opts, cb) {
  opts = opts || {};

  this._aladdin.call(this.name, 'open', opts, cb);

  return this;
};

export default Browser;
