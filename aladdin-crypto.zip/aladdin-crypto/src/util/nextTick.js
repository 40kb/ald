export default function nextTick(fn) {
  setTimeout(fn);
}
