//
//  Dialog.m
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/15.
//  Copyright © 2016年 WQ. All rights reserved.
//


//判断系统版本
#define IOS8_OR_LATER   ([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0)
#define IOS10_OR_LATER   ([[[UIDevice currentDevice] systemVersion] floatValue]>=10.0)


#define Type_Alert      @"alert"

#import "ALDDialogView.h"

@interface ALDDialogView ()<UIAlertViewDelegate>

@property (nonatomic, copy) NSString *alertEnterBackMethod;             /**< alert-确定回调方法名 */
@property (nonatomic, copy) NSString *confirmLeftBtnCallBackMethod;     /**< confirm-确定回调方法名 */
@property (nonatomic, copy) NSString *confirmRightBtnCallBackMethod;    /**< confirm-确定回调方法名 */

@property (nonatomic,strong) UIAlertView * alertview;
@property (nonatomic,strong) UIAlertController *alertViewController;

@property (nonatomic, copy) NSString *type;                             /**< 弹框类型：alert、confirm */

@property (nonatomic, copy) AlertEnterBlock  alertEnterBlock;           /**< alert-确定回调 */
@property (nonatomic, copy) AlertEnterBlock  confirmEnterBlock;         /**< confirm-确定回调 */
@property (nonatomic, copy) AlertCancelBlock confirmCancelBlock;        /**< confirm-取消回调 */

@end

@implementation ALDDialogView

+(ALDDialogView *)shareDialog {
    
    static ALDDialogView *dialog;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dialog = [[ALDDialogView alloc] init];
    });
    return dialog;
}

- (void)alertWithType:(NSString *)type Title:(NSString *)title Message:(NSString *)message ButtonTitle:(NSString *)buttonTitle EnterCallBack:(AlertEnterBlock)enterBlock
{
    _type = type;
    _alertEnterBlock = enterBlock;
    
    NSString *btnText = [buttonTitle copy];
    if (!btnText.length) {
        btnText = @"确定";
    }
    //显示提示框
    [self showAlerViewWithTitle:title Message:message ButtonText:btnText OtherButtonTxts:nil];
    
}

- (void)confirmWithType:(NSString *)type Title:(NSString *)title Message:(NSString *)message LeftButtonTitle:(NSString *)leftButtonTitle LeftButtonCallBackBlock:(AlertEnterBlock)leftButtonCallBackBlock RightButtonTitle:(NSString *)rightButtonTitle RightButtonCallBackBlock:(AlertCancelBlock)rightButtonCallBackBlock
{
    _type = type;
    _confirmCancelBlock = leftButtonCallBackBlock;
    _confirmEnterBlock = rightButtonCallBackBlock;
    //左按钮
    NSString *leftBtnTitle = [leftButtonTitle copy];
    if (!leftBtnTitle.length) {
        leftBtnTitle = @"取消";
    }
    //右按钮
    NSString *rightBtnTitle = [rightButtonTitle copy];
    if (!rightBtnTitle.length) {
        rightBtnTitle = @"确定";
    }
    //显示提示框
    [self showAlerViewWithTitle:title Message:message ButtonText:leftBtnTitle OtherButtonTxts:rightBtnTitle];
}

//提示框
-(void)showAlerViewWithTitle:(NSString *)title Message:(NSString *)message ButtonText:(NSString *)buttonText OtherButtonTxts:(NSString *)otherButtonText{
    if(IOS10_OR_LATER) {
        _alertViewController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        
        //取消按钮
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:buttonText style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            NSLog(@"-->cancelAction");
            
            if ([_type isEqualToString:Type_Alert]) {
                if (_alertEnterBlock) {
                    _alertEnterBlock();
                }
            } else
            {
                if(_confirmCancelBlock)
                {
                    _confirmCancelBlock();
                }
            }
        }];
        
        if([_type isEqualToString:Type_Alert])
        {
            [_alertViewController addAction:cancelAction];
        }
        else
        {
            [_alertViewController addAction:cancelAction];
            //其他按钮
            UIAlertAction *otherAction = [UIAlertAction actionWithTitle:otherButtonText style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                NSLog(@"-->confirmAction");
                if(_confirmEnterBlock)
                {
                    _confirmEnterBlock();
                }
            }];
            [_alertViewController addAction:otherAction];
        }
       
        UIViewController *rootController = [[UIApplication sharedApplication].keyWindow rootViewController];
        [rootController presentViewController:_alertViewController animated:NO completion:nil];
    }else {
        _alertview = [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:buttonText otherButtonTitles: otherButtonText,nil];
        [_alertview show];
   }
}


#pragma mark UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        //取消/左侧按钮回调
        if ([_type isEqualToString:Type_Alert]) {
            //alert
            if (_alertEnterBlock) {
                _alertEnterBlock();
            }
        } else
        {
            //confirm
            if (_confirmCancelBlock) {
                _confirmCancelBlock();
            }
        }
    }else {
        //右侧按钮回调
        if (_confirmEnterBlock) {
            _confirmEnterBlock();
        }
    }
}

@end
