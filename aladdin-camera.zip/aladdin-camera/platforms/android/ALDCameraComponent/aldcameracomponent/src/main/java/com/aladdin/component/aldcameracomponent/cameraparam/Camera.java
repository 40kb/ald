package com.aladdin.component.aldcameracomponent.cameraparam;

import android.app.Activity;

/**
 * Created by as-ipone on 16/8/23.
 */
public class Camera extends CameraProgress {

    public Camera(Activity activity) {
        super(activity);
    }
}
