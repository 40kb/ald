//
//  DevicePlayAudio.h
//  PAiPhoneBank3.0
//
//  Created by 李想 on 16/9/29.
//  Copyright © 2016年 熊剑明. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface DevicePlayAudio : NSObject

//创建DevicePlayAudio单例对象
+ (instancetype)sharePlayAudio;

//播放音乐
- (void)playMusic:(NSString*)musicName;

//停止播放
- (void)stop;

//暂停播放
- (void)pause;

@end
