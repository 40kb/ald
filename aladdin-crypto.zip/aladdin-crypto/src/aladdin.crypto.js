'use strict';
import aladdin from 'aladdin';
import readonlyProperty from './util/readonlyProperty';

function Crypto(aladdin) {
  this._aladdin = aladdin;
}

readonlyProperty(Crypto.prototype, 'name', 'crypto');

/**
 * 根据指定的加密类型，加密源字符，返回加密后的字符（RSA | DES 所需的秘钥，全部由Native维护,H5不介入）
 *
 * @param {Object} opts
 * @param {Function} cb
 * @returns this
 */
Crypto.prototype.encrypt = function(opts, cb) {
  opts = opts || {};
  this._aladdin.call(this.name, 'encrypt', opts, cb);
  return this;
};

/**
 * 根据指定的解密类型，解密源字符，返回加密前的字符(注意：不支持MD5方式解密，RSA | DES 所需的秘钥，全部由Native维护,H5不介入)
 *
 * @param {Object} opts
 * @param {Function} cb
 * @returns this
 */
Crypto.prototype.decrypt = function(opts, cb) {
  opts = opts || {};
  this._aladdin.call(this.name, 'decrypt', opts, cb);
  return this;
};

aladdin.use(Crypto);

export default aladdin.crypto;
