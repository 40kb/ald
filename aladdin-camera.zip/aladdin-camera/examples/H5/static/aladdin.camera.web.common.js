/*! aladdin.camera v1.0.0 (c) 2016-2018 Aladdin */
'use strict';

function __$styleInject(css, returnValue) {
  if (typeof document === 'undefined') {
    return returnValue;
  }
  css = css || '';
  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';
  head.appendChild(style);
  
  if (style.styleSheet){
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
  return returnValue;
}

function Camera(aladdin) {

}

Object.defineProperty(Camera.prototype, 'name', {
  value: 'camera',
  writable: false
});
var inputElem = '';
Camera.prototype.getPhotos = function(options, callback) {
  if (typeof callback !== 'function') {
    return this;
  }
  options = options || {};

  inputElem = document.createElement('input');
  inputElem.setAttribute('type', 'file');
  inputElem.setAttribute('accept', 'image/png, image/jpeg');
  inputElem.style.cssText = 'opacity:0;width:0;height:0;position: absolute;';
  inputElem.addEventListener('change', function() {
    var file = this.files[0];
    var reader = new FileReader();
    reader.onload = function() {
      // 通过 reader.result 来访问生成的 DataURL
      getDataUrl(reader.result, options, function(dataUrl) {
        if (dataUrl) {
          var photos = [];
          photos[0] = (options.returnType === 'base64' ? dataUrl.split(',')[1] : dataUrl);
          callback(null, photos);
          inputElem.remove();
        } else {
          callback({
            code: '',
            message: '处理图片失败'
          });
          inputElem.remove();
        }
      });
    };
    reader.onerror = function() {
      callback({
        code: '',
        message: '读取图片失败'
      });
      inputElem.remove();
    };
    reader.readAsDataURL(file);
  });

  var evt = document.createEvent('MouseEvents');
  evt.initEvent('click', true, true);
  inputElem.dispatchEvent(evt);

  return this;
};

function getDataUrl(url, options, callback) {
  var image = new Image();
  image.onload = function() {
    var opt = {
      width: options.width || image.naturalWidth,
      height: options.height || image.naturalHeight,
      type: options.type === 'png' ? 'image/png' : 'image/jpeg',
      quality: isNaN(options.quality) ? 1 : options.quality / 100
    };

    var canvas = document.createElement('canvas');
    canvas.id = 'canvas';
    canvas.setAttribute('width', opt.width);
    canvas.setAttribute('height', opt.height);
    var ctx = canvas.getContext('2d');
    ctx.drawImage(image, 0, 0, opt.width, opt.height);
    var data = canvas.toDataURL(opt.type, opt.quality);
    typeof callback === 'function' && callback(data);
  };
  image.onerror = function() {
    typeof callback === 'function' && callback(null);
  };
  image.src = url;
}

module.exports = Camera;
