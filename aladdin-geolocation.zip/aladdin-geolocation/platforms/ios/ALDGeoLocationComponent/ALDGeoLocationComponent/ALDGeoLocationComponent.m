//
//  ALDGetLocation.m
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/19.
//  Copyright © 2016年 WQ. All rights reserved.
//

#import "ALDGeoLocationComponent.h"
#import "ALDGetUserLocation.h"

@implementation ALDGeoLocationComponent

ALD_Custom_Module(geolocation);

-(void)getCurrentPosition:(ALDJSWebView *)webView :(NSString *)callBack
{
    [[ALDGetUserLocation shareLocation] getUserLocationWithCallBack:^(GetLocationErrorType errorType, NSDictionary *locationDataDic, NSDictionary *errorDic) {
        if (errorType == GetLocation_Error_None) {
            //无错误回调
            [webView callBack_Json:callBack params:@[locationDataDic] err:nil];
        } else
        {
            //错误回调
        ALDError *errCode = [ALDError customErrorWithCode:[ALDCommonTools convertWithObject:errorDic[@"code"]] message: errorDic[@"message"] appIdentifier:nil customParam:nil];
           
            [webView callBack:callBack params:nil err:errCode];
        }
    }];
}

@end
