package com.aladdin.component.aldaescomponent;



import android.util.Log;

import com.pingan.aladdin.core.Debuger;

import com.pingan.aladdin.core.exception.CallbackNotNullException;
import com.pingan.aladdin.h5.webview.AladdinWebView;
import com.pingan.aladdin.h5.webview.plugin.AladdinJSExecutor;
import com.pingan.aladdin.h5.webview.plugin.HybridComponent;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 * Created by as-ipone on 17/4/27.
 */

public class ALDAESComponent  extends HybridComponent {

    @Override
    public String getName() {
        return "AES";
    }

    @Override
    public boolean isActivityCallbackEnable() {
        return false;
    }

    public void decrypt(final AladdinWebView webView, final JSONObject jsonObject, final String callback){
        JSONObject jsonOb;
        try {
            jsonOb = new JSONObject();
            jsonOb.put("message",AESCipher.aesDecrypt(jsonObject,webView,callback));
            AladdinJSExecutor.callJSONObjectToJS(webView,callback,jsonOb,null);
        } catch (InvalidKeyException e) {
            Debuger.logE(e.toString());
        } catch (NoSuchAlgorithmException e) {
            Debuger.logE(e.toString());
        } catch (NoSuchPaddingException e) {
            Debuger.logE(e.toString());
        } catch (InvalidAlgorithmParameterException e) {
            Debuger.logE(e.toString());
        } catch (IllegalBlockSizeException e) {
            Debuger.logE(e.toString());
        } catch (BadPaddingException e) {
            Debuger.logE(e.toString());
        } catch (UnsupportedEncodingException e) {
            Debuger.logE(e.toString());
        }catch (JSONException e){
            Debuger.logE(e.toString());
        }catch (CallbackNotNullException e){
            Debuger.logE(e.toString());
        }
    }

    public void encrypt(final AladdinWebView webView, final JSONObject jsonObject, final String callback){
        JSONObject jsonOb;
        try {
            jsonOb = new JSONObject();
            jsonOb.put("message",AESCipher.aesEncryp(jsonObject,webView,callback));
            AladdinJSExecutor.callJSONObjectToJS(webView,callback,jsonOb,null);
        } catch (InvalidKeyException e) {
            Debuger.logE(e.toString());
        } catch (NoSuchAlgorithmException e) {
            Debuger.logE(e.toString());
        } catch (NoSuchPaddingException e) {
            Debuger.logE(e.toString());
        } catch (InvalidAlgorithmParameterException e) {
            Debuger.logE(e.toString());
        } catch (IllegalBlockSizeException e) {
            Debuger.logE(e.toString());
        } catch (BadPaddingException e) {
            Debuger.logE(e.toString());
        } catch (UnsupportedEncodingException e) {
            Debuger.logE(e.toString());
        }catch (JSONException e){
            Debuger.logE(e.toString());
        }catch (CallbackNotNullException e){
            Debuger.logE(e.toString());
        }

    }
}


