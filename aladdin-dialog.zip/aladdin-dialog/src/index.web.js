import aladdin from 'aladdin';
import Dialog from './component/aladdin.dialog.web';

aladdin.use(Dialog, 'dialog');

export default aladdin.dialog