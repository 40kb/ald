//
//  Camera.h
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/16.
//  Copyright © 2016年 WQ. All rights reserved.
//

typedef enum {
    Camera_Error_None,                  // 没有错误
    Camera_Error_Normal,                // 相机权限认证失败
    Photos_Error_Normal                 // 相册权限认证失败
} CameraErrorType;

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "TZImagePickerController.h"


/**
 *  @brief 获取照片回调
 *
 *  @param errorType 错误类型
 *  @param photo     照片
 *  @param errorDic  错误信息
 */
typedef void(^GetPhotoCallBackBlock)(CameraErrorType errorType,NSArray *photosArray,NSDictionary *errorDic);

@interface ALDCameraView : NSObject<TZImagePickerControllerDelegate>

+(ALDCameraView *)shareCamera;

/**
 *  @brief                      获取照片
 *
 *  @param source               默认照片来源（1: 拍照，2: 相册，默认为1）
 *  @param edit                 选取照片后是否编辑（默认NO）
 *  @param heght                照片高度（单位px，默认照片高度）
 *  @param width                照片宽度（单位px，默认照片宽度）
 *  @param quality              照片质量（1-100，默认为原图）
 *  @param photoType            照片类型（jpg | png，默认为jpg）
 *  @param selectNum            最大可选取个数，默认为1(暂时只支持选一张)
 *  @param returnType           返回的照片类型（uri | base64，默认为uri）
 *  @param callBackBlock        block回调
 *  @param block.errorType      CameraErrorType
 *  @param block.photosArray    图片(NSArray）
 *  @param block.errorDic       错误信息（NSDictionary）
 */
- (void)getPhotoWithPhotoSource:(NSInteger)source EditEnable:(BOOL)edit PhotoHeight:(CGFloat)heght PhotoWidth:(CGFloat)width PhotoQuality:(CGFloat)quality PhotoType:(NSString *)photoType MaxSelectNum:(NSInteger)selectNum ReturnType:(NSString *)returnType CallBackBlock:(GetPhotoCallBackBlock)callBackBlock;




@end
