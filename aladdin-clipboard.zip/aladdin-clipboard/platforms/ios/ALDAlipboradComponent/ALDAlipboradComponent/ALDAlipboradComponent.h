//
//  PAClipboradPlugin.h
//  PAiPhoneBank3.0
//
//  Created by 高丙超 on 2016/10/11.
//  Copyright © 2016年 熊剑明. All rights reserved.
//

#import <AladdinHybrid/AladdinHybrid.h>

@interface ALDAlipboradComponent : ALDHybridBridge


/**
 拷贝内容到剪切板

 @param webView  ALDJSWebView实例
 @param jsonStr  opts对象
        opts.copyStre  String	拷贝到剪切板上的内容
 
 @param callBack callBack回调
 */
- (void)copy:(ALDJSWebView *)webView :(NSString *)jsonStr :(NSString *)callBack;



/**
 清除剪切板上的内容

 @param webView  ALDJSWebView实例
 @param callBack callBack回调
 */
- (void)clear:(ALDJSWebView *)webView :(NSString *)callBack;

@end
