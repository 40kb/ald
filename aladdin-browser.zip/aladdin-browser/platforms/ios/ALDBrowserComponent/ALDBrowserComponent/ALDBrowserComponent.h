//
//  ALDBrowse.h
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/21.
//  Copyright © 2016年 WQ. All rights reserved.
//

#import <AladdinHybrid/AladdinHybrid.h>
@interface ALDBrowserComponent : ALDHybridBridge

/**
 *  @brief 打开浏览器
 *
 *  @param webView      ALDJSWebView
 *  @param json         json字符串
 *  @param callBack     block回调
 */
- (void)open:(ALDJSWebView *)webView :(NSString *)json :(NSString *)callBack;

@end
