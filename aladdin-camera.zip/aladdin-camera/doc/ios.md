# ALDCamera扩展组件接入文档

## aladdin环境配置
Aladdin接入方式详见 <a href='http://10.20.20.177/guide/'>官网</a>。

## 组件下载
组件下载<a href='http://git-ma.paic.com.cn/aladdin-components/aladdin-camera.git'>仓库地址</a>
</br>

## 接入
### 添加到宿主工程
<image src='images/ALDCamera_01.png'>
 将`ALDCamera.xcodeproj`引入工程
 <image src='images/ALDCamera_02.png'>
  </br>
 拷贝`ALDCamera.bundle`放入主工程资源目录下

### 组件工程配置
在`ALDCamera.xcodeproj`的`Build Setting`配置`Framework Search Paths`，路径为`AladdinHybrid.framework和AladdinBase.framework`所在工程的路径。
<image src='images/ALDCamera_03.png'>


### 添加静态库
在主工程中将生成的`libALDCamera.a`添加到工程中
<image src='images/ALDCamera_04.png'>


## 工程的使用及扩展
需要调用camera，引入#import `<ALDCamera/ALDCameraView.h>`||`<ALDCamera/ALDCamera.h>`,或者需要对其中的方法进行冲定义，可以重写里面的方法。
<image src='images/ALDCamera_05.png'>

