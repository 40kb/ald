package com.aladdin.component.aldcameracomponent;


import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;


import com.aladdin.component.aldcameracomponent.cameraparam.Camera;
import com.aladdin.component.aldcameracomponent.cameraparam.CameraCallback;
import com.pingan.aladdin.core.Debuger;
import com.pingan.aladdin.core.exception.CallbackNotNullException;
import com.pingan.aladdin.core.exception.errorManager.AladdinErrorMessage;
import com.pingan.aladdin.core.resource.metaData.ResourceMetaDataMananger;
import com.pingan.aladdin.h5.webview.AladdinWebView;
import com.pingan.aladdin.h5.webview.plugin.AladdinJSExecutor;
import com.pingan.aladdin.h5.webview.plugin.HybridComponent;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedList;


public class ALDCameraComponent extends HybridComponent {

    private static Handler handler = new Handler(Looper.getMainLooper());
    public String callback;
    //    private CameraProgress cameraProgress;
    private Camera cameraProgress;
    private String pluginName = "camera";

    public ALDCameraComponent() {
    }

    public ALDCameraComponent(String pluginName) {
        this.pluginName = pluginName;
    }

    public String getName() {
        return pluginName;
    }

    @Override
    public boolean isActivityCallbackEnable() {
        return true;
    }

    @JavascriptInterface
    public void getPhotos(final AladdinWebView webView, String msg, final String callBack) {

//        Intent intent = new Intent(webView.getContext(), MainActivity.class);
//        intent.putExtra("select",9);
//        ((Activity)webView.getContext()).startActivityForResult(intent, 0);

        final CameraParam cameraParam = (CameraParam) ResourceMetaDataMananger.getResult(msg, CameraParam.class);
        handler.post(new Runnable() {
            public void run() {
                ALDCameraComponent.this.callback = callBack;
                cameraProgress = new Camera((Activity) getContext(webView));
                cameraProgress.setCameraCallback(new HybrodCameraCallback(webView));
                cameraProgress.getImage(cameraParam.getCameraParam());
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (cameraProgress != null) {
            cameraProgress.onActivityResult(requestCode, resultCode, data);
        }
    }

    String getJSResult(String value) {
        String result = null;
        JSONArray jsonArray = new JSONArray();

        try {
            jsonArray.put(0, value);
            result = jsonArray.toString();
        } catch (JSONException var5) {
            var5.printStackTrace();
        }

        return result;
    }


    class HybrodCameraCallback implements CameraCallback {
        private AladdinWebView webView;

        public HybrodCameraCallback(AladdinWebView webView) {
            this.webView = webView;
        }

        public void onCameraComplete(int code, AladdinErrorMessage message, String data) {
            if (code == 0) {
                JSONObject jsValue = null;
                try {
                    jsValue = new JSONObject(data);
                } catch (JSONException e) {
                    Debuger.logD(e.getMessage());
                }
                try {
                    JSONArray jsonArray = new JSONArray();
                    jsonArray.put(jsValue);
                    AladdinJSExecutor.callJSONArrayTOJS(this.webView, ALDCameraComponent.this.callback, jsonArray, null);
                } catch (Exception e) {
                    Debuger.logD(e.getMessage());
                }

            } else {
                try {
                    AladdinJSExecutor.callStringToJS(this.webView, ALDCameraComponent.this.callback, (String) null, message);
                } catch (Exception e1) {
                    Debuger.logD(e1.getMessage());
                }

            }

        }

        @Override
        public void onMaxCameraComplete(int code, AladdinErrorMessage message, LinkedList<JSONObject> data) {
            JSONArray jsonArray = new JSONArray();
            for (int i = 0; i < data.size(); i++) {
                JSONObject msg = data.get(i);
                try {
                    jsonArray.put(i, msg);
                } catch (JSONException e) {
                    Debuger.logE(e.toString());
                }
            }
            final JSONArray mjsonArray = jsonArray;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        AladdinJSExecutor.callJSONArrayTOJS(webView, ALDCameraComponent.this.callback, mjsonArray, null);
                    } catch (CallbackNotNullException e) {
                        Debuger.logE(e.toString());
                    }
                }
            });


        }
    }
}
