//
//  Camera.m
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/16.
//  Copyright © 2016年 WQ. All rights reserved.
//

/**< 照片来源-相机 */
#define DefaultSource_Camera        1
/**< 照片来源-照片 */
#define DefaultSource_Photo         2
/**< 默认返回类型 */
#define DefaultRetureType           @"uri"
/**< jpg压缩比 */
#define DefaultQuality              1.0
/**< 默认返回类型 .jpg */
#define DefaultType                 @"jpg"

/**< 错误回调的key */
#define CodeKey                     @"code"
#define MessageKey                  @"message"

/**< 访问相机失败 */
#define CallCameraFailure           @21100
/**< 访问相册失败 */
#define CallPhotoFailure            @21101

//判断系统版本
#define IOS8_OR_LATER               ([[[UIDevice currentDevice] systemVersion] doubleValue]>=8.0)
//caches目录
#define DocumentPath                  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject]

#define KeyWindow   [UIApplication sharedApplication].keyWindow

#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <AladdinHybrid/AladdinHybrid.h>

#import "ALDCameraView.h"

@interface ALDCameraView ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@property (nonatomic, assign) NSInteger source;         /**< 照片来源  1：拍照  2：相册 */
@property (nonatomic, assign) CGFloat photoHeight;      /**< 照片高度 */
@property (nonatomic, assign) CGFloat photoWidth;       /**< 照片宽度 */
@property (nonatomic, assign) CGFloat photoQuality;     /**< 照片质量(1-100) */
@property (nonatomic, copy) NSString *photoType;        /**< 照片类型（jpg/png） */
@property (nonatomic, copy) NSString *returnType;       /**< 返回的照片类型（uri/base64) */
@property (nonatomic, assign) BOOL isEdit;              /**< 选取照片后是否编辑（默认false) */
@property (nonatomic, assign) NSInteger selectMaxNum;   /**< 照片最大可选数量 */
@property (nonatomic,strong) UIAlertView * alertview;
@property (nonatomic, copy) GetPhotoCallBackBlock callBackBlock;  /**< 获取照片回调 */
@end

@implementation ALDCameraView

+(ALDCameraView *)shareCamera {
    static ALDCameraView *camera;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        camera = [[ALDCameraView alloc] init];
    });
    return camera;
}

- (void)getPhotoWithPhotoSource:(NSInteger)source EditEnable:(BOOL)edit PhotoHeight:(CGFloat)heght PhotoWidth:(CGFloat)width PhotoQuality:(CGFloat)quality PhotoType:(NSString *)photoType MaxSelectNum:(NSInteger)selectNum ReturnType:(NSString *)returnType CallBackBlock:(GetPhotoCallBackBlock)callBackBlock
{
    _callBackBlock = callBackBlock;
    _source = source;
    _returnType = returnType;
    _isEdit = edit;
    _photoWidth = width;
    _photoHeight = heght;
    _photoQuality = quality/100.0;
    _photoType = photoType;
    _selectMaxNum = selectNum;
    [self setDefaultParams];
    [self selectPhotoSource];

}

-(void)setDefaultParams {
    if (_source != 1 && _source != 2) {
        _source = DefaultSource_Camera;
    }
    if (![_returnType isEqualToString:@"uri"] && ![_returnType isEqualToString:@"base64"] && ![_returnType isEqualToString:@"all"]) {
        _returnType = DefaultRetureType;
    }
    if (_photoQuality < 0 || _photoQuality > 1.0) {
        _photoQuality = DefaultQuality;
    }
    if (![_photoType isEqualToString:@"jpg"] && ![_photoType isEqualToString:@"png"]) {
        _photoType = DefaultType;
    }
}

//选择照片来源
-(void)selectPhotoSource {
    if (_source == DefaultSource_Camera) {
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
            if (status == AVAuthorizationStatusRestricted || status == AVAuthorizationStatusDenied) {
                //未授权访问相机
                if (_callBackBlock) {
                    _callBackBlock(Camera_Error_Normal,nil,@{CodeKey:CallCameraFailure,MessageKey:@"未授权访问相机 \n 请在“设置-隐私-相机”选项中，允许本应用访问您的相机。"});
                }

            } else {
                [self getPhotoWithSourceType:UIImagePickerControllerSourceTypeCamera];
            }
            
        }
    } else {
        ALAuthorizationStatus status = [ALAssetsLibrary authorizationStatus];
        if (status == ALAuthorizationStatusRestricted || status == ALAuthorizationStatusDenied) {
            //未授权访问照片
            if (_callBackBlock) {
                _callBackBlock(Photos_Error_Normal,nil,@{CodeKey:CallPhotoFailure,MessageKey:@"未授权访问照片 \n 请在“设置-隐私-照片”选项中，允许本应用访问您的照片。"});
            }

        } else {
            if (_selectMaxNum>1) {
                TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:_selectMaxNum  delegate:self];
                imagePickerVc.allowTakePicture=NO;
                imagePickerVc.sortAscendingByModificationDate = NO;
                imagePickerVc.isSelectOriginalPhoto =YES;
                 [KeyWindow.rootViewController presentViewController:imagePickerVc animated:YES completion:nil];
                [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
                    [self callBackWithImage:photos];
                }];
            }else{
                [self getPhotoWithSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
                
            }
           
        }
    }
}

-(void)getPhotoWithSourceType:(UIImagePickerControllerSourceType)type {
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    
    imagePicker.delegate = self;
    imagePicker.allowsEditing = _isEdit;
    imagePicker.sourceType = type;
    [KeyWindow.rootViewController presentViewController:imagePicker animated:YES completion:nil];
}

//导航栏即将出现
- (void)navigationController:(UINavigationController *)navigationController
      willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0) {
        viewController.edgesForExtendedLayout = UIRectEdgeNone;
        viewController.extendedLayoutIncludesOpaqueBars = NO;
        viewController.modalPresentationCapturesStatusBarAppearance = NO;
    }
    
    NSDictionary *textAttributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                    [UIColor whiteColor],
                                    UITextAttributeTextColor,
                                    [UIColor darkGrayColor],
                                    UITextAttributeTextShadowColor,
                                    [UIFont boldSystemFontOfSize:20.0],
                                    UITextAttributeFont,
                                    nil];
    [[UINavigationBar appearance] setTitleTextAttributes:textAttributes];
    
    UIImage *navbarImage = [ALDCommonTools createImageWithColor:[UIColor colorWithRed:0.298 green:0.298 blue:0.298 alpha:1.00]];
    [navigationController.navigationBar
     setBackgroundImage:navbarImage
     forBarMetrics:UIBarMetricsDefault];
     [[UIBarButtonItem appearance] setTitleTextAttributes:                                                         [NSDictionary dictionaryWithObjectsAndKeys:[ALDCommonTools colorWithHex:@"#ffffff"],UITextAttributeTextColor, nil]forState:UIControlStateNormal];
    navigationController.navigationBar.tintColor = [ALDCommonTools colorWithHex:@"#ffffff"];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma mark - UIImagePickerControllerDelegate
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    [picker dismissViewControllerAnimated:YES completion:nil];

    UIImage *image;
    if (_isEdit) {
        image  = [info objectForKey:UIImagePickerControllerEditedImage];
    } else {
        image  = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    [self callBackWithImage:@[image]];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

//回传照片
-(void)callBackWithImage:(NSArray *)imageArr {
    NSMutableArray * imageStrArr =[NSMutableArray array];
    for (UIImage * image in imageArr) {
        CGFloat width = (_photoHeight * image.size.width)/image.size.height;
        CGFloat height = (_photoWidth *image.size.height)/image.size.width;
        
        if (_photoWidth <= 0 || _photoHeight <= 0) {
            width = image.size.width;
            height = image.size.height;
        } else {
            if (_photoHeight >= height) {
                width = _photoWidth;
                height = height;
            } else {
                width = width;
                height = _photoHeight;
            }
        }
        //裁剪照片
        UIImage *callBackImage = [self transformDownloadedImage:image width:width height:height];
        NSData *imageData;
        //照片格式
        if ([_photoType isEqualToString:DefaultType]) {
            //JPG
            imageData = UIImageJPEGRepresentation(callBackImage, _photoQuality);
        } else {
            //PNG
            imageData = UIImagePNGRepresentation(callBackImage);
        }
        //回调
        NSString *filePath = [self savePhotoPath];
        NSString *imageString = @"";
        
        if ([_returnType isEqualToString:DefaultRetureType]) {
            //uri
            imageString = [NSString stringWithFormat:@"%@/%@%.f%@.%@",filePath,[self randomStringWithLength:6],[NSDate date].timeIntervalSince1970,[self randomStringWithLength:6],_photoType];
            [imageData writeToFile:imageString atomically:YES];
            [imageStrArr addObject:@{@"uri":imageString}];
            
        }else if ([_returnType isEqualToString:@"all"]){
            
            imageString = [NSString stringWithFormat:@"%@/%@%.f%@.%@",filePath,[self randomStringWithLength:6],[NSDate date].timeIntervalSince1970,[self randomStringWithLength:6],_photoType];
            [imageData writeToFile:imageString atomically:YES];
            
            NSString * base64Str = [imageData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithCarriageReturn];
            
            [imageStrArr addObject:@{@"uri":imageString,@"base64":base64Str}];
        }else {
            //base64
            imageString = [imageData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithCarriageReturn];
            [imageStrArr addObject:@{@"base64":imageString}];

        }
        
    }
        //获取照片回调
    if (_callBackBlock) {
        _callBackBlock(Camera_Error_None,imageStrArr,nil);
    }
}

/**
 *  change Image Size W And H
 *
 *  @param image 当前图片
 *  @param w     设置指定的宽
 *  @param h     设置指定的高
 *
 *  @return 返回处理过的图片
 */
-(UIImage*)transformDownloadedImage:(UIImage *)image width:(NSInteger)w height:(NSInteger)h
{
    //缩放图片
    // Create a graphics image context
    UIGraphicsBeginImageContext(CGSizeMake(w, h));
    
    // Tell the old image to draw in this new context, with the desired
    // new size
    [image drawInRect:CGRectMake(0,0,w, h)];
    
    // Get the new image from the context
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // End the context
    UIGraphicsEndImageContext();
    return newImage;
}

#pragma mark - 创建存储图片目录
-(NSString *)savePhotoPath {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *filePath = [DocumentPath stringByAppendingPathComponent:@"/Aladdin/Caches/Image"];
    if (![fileManager fileExistsAtPath:filePath]) {
        BOOL reult = [fileManager createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
        if (!reult) {
            return DocumentPath;
        }
    }
    return filePath;
}

#pragma mark - 获取随机数
- (NSString*)randomStringWithLength:(int)len
{
    NSString*letters =@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    NSMutableString*randomString = [NSMutableString stringWithCapacity: len];
    for(int i =0; i<len; i++)
    {
        [randomString appendFormat:@"%C", [letters characterAtIndex:arc4random_uniform((int)[letters length])]];
    }
    return randomString;
}

#pragma mark - 获取系统当前时间，设置为图片的名称
- (NSString *)getCurrentImageName
{
    //获得系统时间
    NSDate * senddate=[NSDate date];
    NSDateFormatter *dateformatter=[[NSDateFormatter alloc] init];
    [dateformatter setDateFormat:@"YYYYMMddHHmmss"];
    NSString * locationString=[dateformatter stringFromDate:senddate];
    return locationString;
}

@end
