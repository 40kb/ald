package com.aladdin.component.aldaescomponent;

/**
 * Created by as-ipone on 17/5/2.
 */


import com.pingan.aladdin.core.Debuger;
import com.pingan.aladdin.core.exception.CallbackNotNullException;
import com.pingan.aladdin.core.exception.errorManager.ErrorCode;
import com.pingan.aladdin.core.exception.errorManager.ErrorManager;
import com.pingan.aladdin.h5.webview.AladdinWebView;
import com.pingan.aladdin.h5.webview.plugin.AladdinJSExecutor;

import org.json.JSONObject;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;


import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.io.UnsupportedEncodingException;

public class AESCipher {

    private static String result;
    private static String text;
    private static String key;
    private static String iv;
    private static int size;
    private static int mode;
    private static int padding;
    private static String[] paddings = {"pkcs5padding", "Iso97971", "AnsiX923", "Iso10126", "ZeroPadding", "NoPadding"};
    private static String[] modes = {"CBC", "CFB", "CTR", "OFB", "ECB"};

    private static String IV_STRING = "";
    private static String charset = "UTF-8";
    private static String MODE = "AES/CBC/pkcs5padding";

    public static String aesEncryptString(String content, String key) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
        byte[] contentBytes = content.getBytes(charset);
        byte[] keyBytes = key.getBytes(charset);
        byte[] encryptedBytes = aesEncryptBytes(contentBytes, keyBytes);
        return Base64Encoder.encode(encryptedBytes);
    }

    public static String aesDecryptString(String content, String key) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
        byte[] encryptedBytes = Base64Decoder.decodeToBytes(content);
        byte[] keyBytes = key.getBytes(charset);
        byte[] decryptedBytes = aesDecryptBytes(encryptedBytes, keyBytes);
        return new String(decryptedBytes, charset);
    }

    private static byte[] aesEncryptBytes(byte[] contentBytes, byte[] keyBytes) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
        return cipherOperation(contentBytes, keyBytes, Cipher.ENCRYPT_MODE);
    }

    private static byte[] aesDecryptBytes(byte[] contentBytes, byte[] keyBytes) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
        return cipherOperation(contentBytes, keyBytes, Cipher.DECRYPT_MODE);
    }

    private static byte[] cipherOperation(byte[] contentBytes, byte[] keyBytes, int mode) throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");
//        有初始化向量加密，不过ECB模式下当初始化向量为空串时有些手机会报错。
//        byte[] initParam = IV_STRING.getBytes(charset);
//        IvParameterSpec ivParameterSpec = new IvParameterSpec(initParam);
//        Cipher cipher = Cipher.getInstance(MODE);
//        cipher.init(mode, secretKey, ivParameterSpec);

        Cipher cipher = Cipher.getInstance(MODE);
        cipher.init(mode, secretKey);

        return cipher.doFinal(contentBytes);
    }


    public static String aesEncryp(JSONObject jsonObject, AladdinWebView webView ,String callback) throws NoSuchPaddingException, UnsupportedEncodingException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException {
        initData(jsonObject,webView,callback);
        return aesEncryptString(text, key);
    }

    public static String aesDecrypt(JSONObject jsonObject, AladdinWebView webView ,String callback) throws NoSuchPaddingException, UnsupportedEncodingException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException {
        initData(jsonObject,webView,callback);
        return aesDecryptString(text, key);
    }

    public static void initData(JSONObject jsonObject, AladdinWebView webView ,String callback) {
        text = jsonObject.optString("text");
        key = jsonObject.optString("key");
        iv = jsonObject.optString("iv");
        size = jsonObject.optInt("size");
        mode = jsonObject.optInt("mode");
        padding = jsonObject.optInt("padding");
        if (key.length() != 16) {
            try {
                AladdinJSExecutor.callStringToJS(webView, callback, null, ErrorManager.Builder(ErrorCode.CRYPTO_KEYLESS24,"密钥长度需为16字节"));
            } catch (CallbackNotNullException e) {
                Debuger.logD(e.getMessage());
            }
            return;
        }
        MODE = "AES/" + modes[mode] + "/" + paddings[padding];
        if (modes[mode].equals("CBC")) {
            IV_STRING = "16BytesLength111";
        }
    }


}


