//
//  ALDGetLocation.h
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/19.
//  Copyright © 2016年 WQ. All rights reserved.
//

#import <AladdinHybrid/AladdinHybrid.h>

/**  iOS8后，使用定位服务需在工程的Info.plist中添加以下两项
 *
 *    NSLocationAlwaysUsageDescription
 *    NSLocationWhenInUseUsageDescription
 *
 */

@interface ALDGeoLocationComponent : ALDHybridBridge

/**
 *  @brief          获取位置
 *
 *  @param webView  ALDJSWebView
 *  @param callBack 回调方法
 */
-(void)getCurrentPosition:(ALDJSWebView *)webView :(NSString *)callBack;

@end
