/*! aladdin.clipboard v1.0.0 (c) 2016-2017 Aladdin */
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('aladdin')) :
	typeof define === 'function' && define.amd ? define(['aladdin'], factory) :
	(global.aladdin = global.aladdin || {}, global.aladdin.clipboard = factory(global.aladdin));
}(this, (function (aladdin) { 'use strict';

aladdin = 'default' in aladdin ? aladdin['default'] : aladdin;

function Clipboard(aladdin$$1) {
  this._aladdin = aladdin$$1;
}

Object.defineProperty(Clipboard.prototype, 'name', {
  value: 'clipboard',
  writable: false
});

/**
 * 复制文本到剪切板 
 *
 * @param {Object} opts
 * @property {String} copyStr 复制字段名称
 * @param {Function} cb
 */
Clipboard.prototype.copy = function(opts, cb) {
  opts = opts || {};

  return this._aladdin.call(this.name, 'copy', opts, cb);
};

/**
 * 清除剪切板
 *
 * @param {Function} cb
 */
Clipboard.prototype.clear = function(cb) {
  return this._aladdin.call(this.name, 'clear', cb);
};

aladdin.use(Clipboard);

var index = aladdin.clipboard;

return index;

})));
