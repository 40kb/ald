package com.aladdin.component.aldcameracomponent.cameraparam;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.util.Log;


import com.aladdin.component.aldcameracomponent.R;
import com.aladdin.component.aldcameracomponent.ThreadPools;
import com.aladdin.component.aldcameracomponent.chooseMorePic.ImageSelectActivity;
import com.aladdin.component.aldcameracomponent.chooseMorePic.bean.ImageBean;

import com.pingan.aladdin.core.Debuger;
import com.pingan.aladdin.core.base.ActivityCallback;
import com.pingan.aladdin.core.exception.errorManager.AladdinErrorMessage;
import com.pingan.aladdin.core.exception.errorManager.ErrorCode;
import com.pingan.aladdin.core.utils.FileUtil;
import com.pingan.aladdin.core.utils.ImageUtil;

import com.pingan.aladdin.core.utils.UriUtil;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;


public class CameraProgress implements ActivityCallback {
    /**
     * 图片回调码
     */
    public static final int REQUEST_PHOTOS = 100 + 6;
    public static final int REQUEST_PHOTO = 100 + 1;
    public static final int REQUEST_CAMERA = 100 + 2;
    public static final int REQUEST_CORP = 100 + 3;
    public static final int REQUEST_EXOCRENGINE_SCAN = 100 + 4;
    public static final int REQUEST_EXOCRENGINE_PHOTO = 100 + 5;
    private static final String TAG = CameraProgress.class.getSimpleName();
    private Activity context;
    private CameraCallback cameraCallback;
    private Uri imageUri;
    private CameraParam cameraParam;


    private PAProgressDialog mProgressDialog;

    public CameraProgress(Activity activity) {
        context = activity;
    }

    public void setCameraCallback(CameraCallback cameraCallback) {
        this.cameraCallback = cameraCallback;
    }

    public void getImage(CameraParam cameraParam) {

//        if (cameraParam.getMaxSelect() > 1) {
//            this.cameraParam = cameraParam;
//            Intent intent = new Intent(context, ImageSelectActivity.class);
//            intent.putExtra("select", cameraParam.getMaxSelect());
//            (context).startActivityForResult(intent, REQUEST_PHOTOS);
//        } else {
        try {
            int permission = PackageManager.PERMISSION_GRANTED;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                permission = this.context.checkSelfPermission(Manifest.permission.CAMERA);
            }
            if (permission == PackageManager.PERMISSION_GRANTED) {
                this.cameraParam = cameraParam;
                this.imageUri = Uri.fromFile(this.createCaptureFile(this.context, cameraParam.getType(), System.currentTimeMillis() + ""));
                // 相机
                if (cameraParam.getMaxSelect() > 1) {
                    this.cameraParam = cameraParam;
                    Intent intent = new Intent(context, ImageSelectActivity.class);
                    intent.putExtra("select", cameraParam.getMaxSelect());
                    (context).startActivityForResult(intent, REQUEST_PHOTOS);
                } else {
                    if (cameraParam.getSource() == 1) {
                        CameraHelper.camera(this.context, this.imageUri, REQUEST_CAMERA);
                    } else if (cameraParam.getSource() == 2) {
                        // 相册
                        if (cameraParam.isEdit()) {
                            // 选择完成裁剪
                            CameraHelper.cropPick(this.context, cameraParam.getWidth(), cameraParam.getHeight(), this.imageUri, REQUEST_CORP);
                        } else {
                            // 直接返回图片
                            CameraHelper.album(this.context, REQUEST_PHOTO);
                        }
                    }
                }
            } else if (this.cameraCallback != null) {
                AladdinErrorMessage aladdinErrorMessage;
                if (cameraParam.getMaxSelect() > 1 || cameraParam.getSource() == 2) {
                    aladdinErrorMessage = AladdinErrorMessage.build(21101, "相册权限未开启");
                } else {
                    aladdinErrorMessage = AladdinErrorMessage.build(21100, "相机权限未开启");
                }
                this.cameraCallback.onCameraComplete(ErrorCode.REQUEST_CAMERA_PERMISSION_FAIL, aladdinErrorMessage, "");
            }
        } catch (Exception e) {
            Log.i(TAG, "camera plugin error;" + e.getMessage());
            Debuger.logD(e.getMessage());

            AladdinErrorMessage aladdinErrorMessage;
            if (cameraParam.getMaxSelect() > 1 || cameraParam.getSource() == 2) {
                aladdinErrorMessage = AladdinErrorMessage.build(21101, "相册权限未开启");
            } else {
                aladdinErrorMessage = AladdinErrorMessage.build(21100, "相机权限未开启");
            }
            this.cameraCallback.onCameraComplete(ErrorCode.REQUEST_CAMERA_PERMISSION_FAIL, aladdinErrorMessage, "");
        }
    }

//    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        String imgPath;
        switch (requestCode) {
            case REQUEST_PHOTO:
                if (resultCode == Activity.RESULT_OK && this.cameraParam != null) {
                    Uri uri = data.getData();
                    if (uri != null) {
                        imgPath = UriUtil.getPath(this.context, uri);
                        Log.i(TAG, "imgPath;" + imgPath);
                        this.callBackValue(imgPath);
                    }
                }
                break;
            case REQUEST_CAMERA:
                if (resultCode == Activity.RESULT_OK && this.cameraParam != null && this.imageUri != null) {
                    imgPath = this.imageUri.getPath();
                    if (this.cameraParam.isEdit()) {
                        Uri orgUri = Uri.fromFile(new File(imgPath));
                        CameraHelper.cropCamera(this.context, orgUri, this.imageUri, this.cameraParam.getWidth(), this.cameraParam.getHeight(), REQUEST_CORP);
                    } else {
                        this.callBackValue(imgPath);
                    }
                }
                break;
            case REQUEST_CORP:
                if (resultCode == Activity.RESULT_OK && this.cameraParam != null) {
                    imgPath = UriUtil.getPath(this.context, this.imageUri);
                    Log.i(TAG, "imgPath;" + imgPath);
                    this.callBackValue(imgPath);
                }
                break;
            case REQUEST_PHOTOS:
                if (resultCode == Activity.RESULT_OK && this.cameraParam != null) {
                    Bundle bundle = data.getExtras();
                    ArrayList<ImageBean> list = bundle.getParcelableArrayList("selectImages");
                    callBackValue(list);
                }
        }

    }

    public void onCreate(Bundle bundle) {
    }

    public void onDestroy() {
        //需要释放context,防止内存泄露
        if (context != null) {
            context = null;
        }
    }

    public void onPause() {
    }

    public void onRestart() {
    }

    public void onRestoreInstanceState(Bundle bundle) {
    }

    public void onResume() {
    }

    public void onSaveInstanceState(Bundle bundle/*, PersistableBundle persistableBundle*/) {
    }

    public void onStart() {
    }

    public void onStop() {
    }

    private void callBackValue(final String imgPath) {
        ThreadPools.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String data;
                    showLoading();
                    if (cameraParam.getQuality() > 0 && cameraParam.getQuality() < 100) {
                        if ("uri".equals(cameraParam.getReturnType()) || cameraParam.getReturnType() == null) {
                            data = compressImageToPath(imgPath);
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("uri", data);
                            executeCallback(0, null, jsonObject.toString());
                        } else if ("base64".equals(cameraParam.getReturnType())) {
                            data = ImageUtil.compressImageTo64(imgPath, cameraParam.getQuality(), cameraParam.getType());
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("base64", data);
                            executeCallback(0, null, jsonObject.toString());
                        } else if ("all".equals(cameraParam.getReturnType())) {
                            data = compressImageToPath(imgPath);
                            String base64Data = ImageUtil.encodeBase64File(data);
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("uri", data);
                            jsonObject.put("base64", base64Data);
                            executeCallback(0, null, jsonObject.toString());
                        }
                    } else if ("uri".equals(cameraParam.getReturnType()) || cameraParam.getReturnType() == null) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("uri", imgPath);
                        executeCallback(0, null, jsonObject.toString());
                    } else if ("base64".equals(cameraParam.getReturnType())) {
                        data = ImageUtil.encodeBase64File(imgPath);
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("base64", data);
                        executeCallback(0, null, jsonObject.toString());
                    } else if ("all".equals(cameraParam.getReturnType())) {
                        String base64Data = ImageUtil.encodeBase64File(imgPath);
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("uri", imgPath);
                        jsonObject.put("base64", base64Data);
                        executeCallback(0, null, jsonObject.toString());
                    }
                } catch (Exception e) {
                    Debuger.logE(e.getMessage());
                    stopLoading();
                }

            }
        });


    }


    private String compressImageToPath(String imageFilePath) {
        File tempFile = createCaptureFile(context, cameraParam.getType(), System.currentTimeMillis() + "");
        return ImageUtil.compressImageToPath(imageFilePath, tempFile.getAbsolutePath(), cameraParam.getQuality(), cameraParam.getType());
    }

    private void executeCallback(final int code, final AladdinErrorMessage errMessage, final String data) {
        stopLoading();
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (cameraCallback != null) {
                    cameraCallback.onCameraComplete(code, errMessage, data);
                }
            }
        });
    }

    private void showLoading() {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (!context.isFinishing() && (mProgressDialog == null || !mProgressDialog.isShowing())) {
                    mProgressDialog = PAProgressDialog.show(context, R.style.paprogress);
                    mProgressDialog.setCanceledOnTouchOutside(false);
                    mProgressDialog.setCancelable(false);
                }
            }
        });
    }

    private void stopLoading() {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
                mProgressDialog = null;
            }
        });
    }


    File createCaptureFile(Context context, String encodingType, String fileName) {
        if (fileName.isEmpty()) {
            fileName = ".Pic";
        }
        if ("jpg".equals(encodingType)) {
            fileName = fileName + ".jpg";
        } else if ("png".equals(encodingType)) {
            fileName = fileName + ".png";
        } else {
            fileName = fileName + ".jpg";
        }
        String filePath = FileUtil.getSDAppCachePath(context) + File.separator + "image";
        File file = new File(filePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        return new File(filePath, fileName);
    }

    @Override
    public void onBackPressed() {

    }

    @Override
    public void onRequestPermissionsResult(int i, @NonNull String[] strings, @NonNull int[] ints) {

    }


    private void callBackValue(final ArrayList<ImageBean> list) {
        final LinkedList<JSONObject> mlist = new LinkedList();
        ThreadPools.execute(new Runnable() {
            @Override
            public void run() {
                try {

                    String data = null;
                    showLoading();
                    for (int i = 0; i < list.size(); i++) {
                        JSONObject jsonObject = new JSONObject();
                        String imgPath = list.get(i).getPath();
                        if (cameraParam.getQuality() > 0 && cameraParam.getQuality() < 100) {
                            if ("uri".equals(cameraParam.getReturnType()) || cameraParam.getReturnType() == null) {
                                data = compressImageToPath(imgPath);
                                jsonObject.put("uri", data);
//                                executeCallback(0, null, data);
                            } else if ("base64".equals(cameraParam.getReturnType())) {
                                data = ImageUtil.compressImageTo64(imgPath, cameraParam.getQuality(), cameraParam.getType());
                                jsonObject.put("base64", data);
//                                executeCallback(0, null, data);
                            } else if ("all".equals(cameraParam.getReturnType())) {
                                data = compressImageToPath(imgPath);
                                String base64Data = ImageUtil.encodeBase64File(data);
//                                JSONObject jsonObject = new JSONObject();
                                jsonObject.put("uri", data);
                                jsonObject.put("base64", base64Data);
//                                executeCallback(0, null, jsonObject.toString());
                            }
                        } else if ("uri".equals(cameraParam.getReturnType()) || cameraParam.getReturnType() == null) {
                            data = imgPath;
                            jsonObject.put("uri", data);
//                            executeCallback(0, null, imgPath);
                        } else if ("base64".equals(cameraParam.getReturnType())) {
                            data = ImageUtil.encodeBase64File(imgPath);
                            jsonObject.put("base64", data);
//                            executeCallback(0, null, data);
                        } else if ("all".equals(cameraParam.getReturnType())) {
                            String base64Data = ImageUtil.encodeBase64File(imgPath);
//                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("uri", imgPath);
                            jsonObject.put("base64", base64Data);
//                            executeCallback(0, null, jsonObject.toString());
                        }
                        mlist.add(jsonObject);
                    }
                    if (cameraCallback != null) {
                        stopLoading();
                        cameraCallback.onMaxCameraComplete(0, null, mlist);
                    }
                } catch (Exception e) {
                    Debuger.logE(e.getMessage());
                    stopLoading();
                }
            }
        });
    }
}
