//
//  ALDCamera.h
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/18.
//  Copyright © 2016年 WQ. All rights reserved.
//
#import <AladdinHybrid/AladdinHybrid.h>

@interface ALDCameraComponent : ALDHybridBridge

/**
 *  @brief                      获取照片
 *
 *  @param webView               ALDJSWebView实例
 *  @param jsonStr               opts对象
 *         opts.source	         默认照片来源（1: 拍照，2: 相册，默认为1）
 *         opts.returnType	     返回的照片类型（uri | base64，默认为uri）
 *         opts.edit	         选取照片后是否编辑（默认false）
 *         opts.width]		     照片宽度（单位px，默认照片宽度）
 *         opts.height	         照片高度（单位px，默认照片高度度）
 *         opts.quality	         照片质量（1-100，默认为原图）
 *         opts.type             照片类型（jpg | png，默认为jpg）
 *         opts.maxSelect        最大可选取个数，默认为1
 *  @param callBack              回调URL
 *
 */
-(void)getPhotos:(ALDJSWebView *)webView :(NSString *)jsonString :(NSString *)callBack;

@end
