/*! aladdin.browser v1.0.0 (c) 2016-2017 Aladdin */
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('aladdin')) :
	typeof define === 'function' && define.amd ? define(['aladdin'], factory) :
	(global.aladdin = global.aladdin || {}, global.aladdin.browser = factory(global.aladdin));
}(this, (function (aladdin) { 'use strict';

aladdin = 'default' in aladdin ? aladdin['default'] : aladdin;

function Browser(aladdin$$1) {
  this._aladdin = aladdin$$1;
}

Object.defineProperty(Browser.prototype, 'name', {
    value: 'browser',
    writable: false
});

/**
 * 调起浏览器打开网页
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Browser.prototype.open = function (opts, cb) {
  opts = opts || {};

  this._aladdin.call(this.name, 'open', opts, cb);

  return this;
};

aladdin.use(Browser);

var index = aladdin.browser;

return index;

})));
