'use strict';

import aladdin from 'aladdin';
import Browser from './component/aladdin.browser.web';

aladdin.use(Browser);

export default aladdin.browser;