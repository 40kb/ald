package com.aladdin.component.aldgeolocatinoncomponent;

import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;


import com.baidu.location.BDLocation;
import com.pingan.aladdin.core.Debuger;
import com.pingan.aladdin.core.exception.CallbackNotNullException;
import com.pingan.aladdin.core.exception.errorManager.ErrorCode;
import com.pingan.aladdin.core.exception.errorManager.ErrorManager;
import com.pingan.aladdin.core.utils.StringUtil;
import com.pingan.aladdin.h5.webview.AladdinWebView;
import com.pingan.aladdin.h5.webview.plugin.AladdinJSExecutor;
import com.pingan.aladdin.h5.webview.plugin.HybridComponent;

import org.json.JSONObject;

/**
 * @author ex-yangzhenxing001@pingan.com.cn
 * @date 2016/10/8
 */
public class ALDGeolocationComponent extends HybridComponent {
    private String tag = "ALDGeolocationComponent";
    //定位工具对象
    private LocationUtils mLocationUtils;
    @Override
    public String getName() {
        return "geolocation";
    }

    @Override
    public boolean isActivityCallbackEnable() {
        return false;
    }

    @JavascriptInterface
    public void getCurrentPosition(final AladdinWebView aladdinWebView, final String callback) {

        if(mLocationUtils==null){
            mLocationUtils = new LocationUtils(aladdinWebView.getContext());
        }
        boolean isOpenGPS = false;
        isOpenGPS = mLocationUtils.isProviderEnabled();
        if (!isOpenGPS){
            //如果GPS是关闭。则直接返回不做处理
            if (!StringUtil.isEmpty(callback)) {
                try {
                    JSONObject positionJson = new JSONObject();
                    positionJson.put("code",9004);
                    positionJson.put("message","GPS未打开");
                    AladdinJSExecutor.callJSONObjectToJS(aladdinWebView, callback, positionJson, ErrorManager.Builder(ErrorCode.LOCATE_FAIL));
                } catch (CallbackNotNullException e) {
                    Debuger.logD(e.getMessage());
                } catch (Exception e){

                }
            }
            return;
        }
        long timeOutDelay = 40000;
        mLocationUtils.getLocation(timeOutDelay, new LocationUtils.LocationCallback() {

            @Override
            public void onSucceedCallback(BDLocation succedInfo) {
                Debuger.logE(tag, succedInfo.toString());
                Double longitude,latitude;
                JSONObject positionJson = new JSONObject();

                if (succedInfo!=null){
                    latitude =  succedInfo.getLatitude();
                    longitude = succedInfo.getLongitude();
                    try{
                        positionJson.put("longitude",longitude);
                        positionJson.put("latitude",latitude);
                    }catch (Exception e){

                    }
                }
                if (!StringUtil.isEmpty(callback)) {
                    try {
                        AladdinJSExecutor.callJSONObjectToJS(aladdinWebView, callback, positionJson, null);
                    } catch (CallbackNotNullException e) {
                        Debuger.logD(e.getMessage());
                    } catch(Exception e){
                        Debuger.logD(e.getMessage());
                    }
                }

            }

            @Override
            public void onErrorCallback(JSONObject errorInfo) {
                Debuger.logE(tag, errorInfo.toString());
                int code;
                int errorCode = 9004;
                JSONObject positionJson = new JSONObject();
                if (errorInfo!=null){
                    code = errorInfo.optInt("code");
                    if (code == 1){
                        errorCode = 9004;
                    }else if (code == 3){
                        errorCode = 9005;
                    }
                    try{
                        positionJson.put("code",errorCode);
                        positionJson.put("message",errorInfo.toString());
                    }catch (Exception e){
                        Debuger.logD(e.getMessage());
                    }
                }
                final JSONObject tempPositionJson = positionJson;
                if (!StringUtil.isEmpty(callback)) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                AladdinJSExecutor.callJSONObjectToJS(aladdinWebView, callback, tempPositionJson, ErrorManager.Builder(ErrorCode.LOCATE_FAIL));
                            } catch (CallbackNotNullException e) {
                                Debuger.logD(e.getMessage());
                            } catch (Exception e) {
                                Debuger.logD(e.getMessage());
                            }
                        }});
                    }
            }
        });

    }
}
