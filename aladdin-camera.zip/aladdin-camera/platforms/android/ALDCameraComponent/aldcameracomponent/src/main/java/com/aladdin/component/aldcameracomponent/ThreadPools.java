package com.aladdin.component.aldcameracomponent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 线程池工具类
 *
 * @author EX-XIAOFANQING001
 */
public class ThreadPools {
    static ExecutorService mExecutorService = Executors.newCachedThreadPool();
    static ExecutorService mSingleService = Executors.newSingleThreadExecutor();

    /**
     * 把任务交给线程池运行
     *
     * @param task
     */
    public static void execute(Runnable task) {
        mExecutorService.execute(task);
    }

    public static void postTask(Runnable task) {
        mExecutorService.execute(task);
    }

    public static void execSingle(Runnable task) {
        mSingleService.execute(task);
    }
}