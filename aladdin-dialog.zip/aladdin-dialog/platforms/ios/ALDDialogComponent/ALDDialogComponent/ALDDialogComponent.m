//
//  ALDDialog.m
//  ALADINModuleDemo
//
//  Created by WQ on 16/7/18.
//  Copyright © 2016年 WQ. All rights reserved.
//

#import "ALDDialogComponent.h"
#import "ALDDialogView.h"


@implementation ALDDialogComponent

ALD_Custom_Module(dialog);
-(void)alert:(ALDJSWebView *)webView :(NSString *)jsonString :(NSString *)callBack
{
    //获取json数据
    NSDictionary *dataDic = [jsonString objectFromJSONString];

    //显示的标题
   NSString *title = [ALDCommonTools convertWithObject:dataDic[@"title"]];
  
    //显示的消息
    NSString *message =[ALDCommonTools convertWithObject:dataDic[@"message"]];
    //按钮名称
    NSString * btnText =[ALDCommonTools convertWithObject:dataDic[@"buttonText"]];
    //按钮回调方法
    NSString *btnCallBackMethod =dataDic[@"buttonCallback"];
    
    ALDDialogView *dialog = [ALDDialogView shareDialog];
    [dialog alertWithType:@"alert" Title:title Message:message ButtonTitle:btnText EnterCallBack:^{
        //确定回调
        [webView callBack:btnCallBackMethod params:nil err:nil];
    }];
    
    [webView callBack:callBack params:nil err:nil];
}


-(void)confirm:(ALDJSWebView *)webView :(NSString *)jsonString :(NSString *)callBack
{
    //获取json数据
    NSDictionary *dataDic = [jsonString objectFromJSONString];
    if (!dataDic) {
        ALDError * errcode = [ALDError customErrorWithCode:@"10014" message:@"参数异常" appIdentifier:nil customParam:nil];
        [webView callBack:callBack params:nil err:errcode];
        return;
    }
    //显示的标题
    NSString *title = dataDic[@"title"];
    //显示的消息
    NSString *message =  dataDic[@"message"];
    //按钮名称
    NSString *btnText = dataDic[@"leftButtonText"];
    NSString *otherBtnText = dataDic[@"rightButtonText"];
    //左右按钮回调方法
    NSString *rightBtnCallBackMethod = dataDic[@"rightButtonCallback"];
    NSString *leftBtnCallBackMethod = dataDic[@"leftButtonCallback"];
    
    ALDDialogView *dialog = [ALDDialogView shareDialog];
    [dialog confirmWithType:@"confirm" Title:title Message:message LeftButtonTitle:btnText LeftButtonCallBackBlock:^{
        //左按钮回调
        [webView callBack:leftBtnCallBackMethod params:nil err:nil];
    } RightButtonTitle:otherBtnText RightButtonCallBackBlock:^{
        //右按钮回调
        [webView callBack:rightBtnCallBackMethod params:nil err:nil];
    }];
    
    [webView callBack:callBack params:nil err:nil];
}

@end
