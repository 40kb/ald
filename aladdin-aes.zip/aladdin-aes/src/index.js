'use strict';
import aladdin from 'aladdin';
import Aes from './component/aladdin.aes'; 
aladdin.use(Aes);
export default aladdin.aes;