'use strict';

function Dialog(aladdin) {
  this._aladdin = aladdin;
}


Object.defineProperty(Dialog.prototype, 'name', {
  value: 'dialog',
  writable: false
});


Dialog.prototype.alert = function(opts, cb) {
  opts = opts || {};
  this._aladdin.call(this.name, 'alert', opts, cb);
}

Dialog.prototype.confirm = function(opts, cb) {
  opts = opts || {};
  this._aladdin.call(this.name, 'confirm', opts, cb);
}

export default Dialog;