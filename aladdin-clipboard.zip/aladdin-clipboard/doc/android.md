# ALDAlipboradComponent(Android)扩展组件接入文档

## aladdin环境配置
Aladdin接入方式详见 <a href='http://10.20.20.177/guide/'>官网</a>。

## 组件下载
组件下载<a href='http://git-ma.paic.com.cn/aladdin-components/aladdin-clipboard.git'>仓库地址</a>
</br>

## 接入

### 添加到宿主工程

 将从git下载的组件以`ALDAlipboradComponent`这级目录作为一个module import进工程。

### 组件注册以及使用

### 调用下述api将扩展组件加入aladdin组件列表。
   `HybridComponentMananger.getInstance().injectPlugin(ALDAlipboradComponent.class)`

## 常见问题
### 组件工程配置
如果引入camera组件某些类import的包报红，则需修改build.gradled下的copile project(),依赖aladdin.jar即可
<image src='images/buildgradle_2.png'>

### 导入组件编译不通过
#### android:allowbackup 
包冲突解决了，如果还有编译不通过问题，可能是由于组件工程下的AndroidManifest里面aplication标签下` android:allowBackup="true"`改为false 或者作如下修改
<image src='images/mainfest_4.png'>
