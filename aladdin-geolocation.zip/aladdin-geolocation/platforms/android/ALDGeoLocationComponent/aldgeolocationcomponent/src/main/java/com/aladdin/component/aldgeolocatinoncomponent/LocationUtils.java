package com.aladdin.component.aldgeolocatinoncomponent;

import android.content.Context;
import android.location.LocationManager;


import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.pingan.aladdin.core.Debuger;
//import com.pingan.core.data.PADataAgent;
//import com.pingan.core.data.engine.GPSLocation;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Timer;
import java.util.TimerTask;


public class LocationUtils {
	
	public LocationClient mLocationClient = null;
	/** 定位监听 **/
	private MyLocationListenner myListener = new MyLocationListenner();
	
	private Context mContext = null;
	
	private LocationCallback mCallback = null;
	
	private Timer mTimer = new Timer();
	
	public LocationUtils(Context context){
		mContext = context;
		mLocationClient = new LocationClient(mContext.getApplicationContext());
		mLocationClient.registerLocationListener(myListener);
		setLocationOption();
	}
	
	public void getLocation(long timeOutDelay,LocationCallback callback){
		this.mCallback = callback;
		if(!mLocationClient.isStarted()){
			if(isProviderEnabled()){
				mLocationClient.getLocOption().setOpenGps(true);
				mLocationClient.getLocOption().setPriority(LocationClientOption.GpsFirst);
			}else{
				mLocationClient.getLocOption().setPriority(LocationClientOption.NetWorkFirst);
			}
			mLocationClient.start();
			mLocationClient.requestLocation();


			Debuger.logD("获取地理位置:startLocationClient");
		}
		resetTimer(timeOutDelay);
	}
	
	/**
	 * 监听函数
	 */
	private class MyLocationListenner implements BDLocationListener {
		
		@Override
		public void onReceiveLocation(BDLocation location) {
			Debuger.logD("获取地理位置1:onReceiveLocation");
			if(location == null) return ;
			
//			返回值： 
//			61 ： GPS定位结果 
//			62 ： 扫描整合定位依据失败。此时定位结果无效。 
//			63 ： 网络异常，没有成功向服务器发起请求。此时定位结果无效。 
//			65 ： 定位缓存的结果。 
//			66 ： 离线定位结果。通过requestOfflineLocaiton调用时对应的返回结果 
//			67 ： 离线定位失败。通过requestOfflineLocaiton调用时对应的返回结果 
//			68 ： 网络连接失败时，查找本地离线定位时对应的返回结果 
//			161： 表示网络定位结果 
//			162~167： 服务端定位失败。 
			int type = location.getLocType();
			switch(type){
				case 61:
				case 65:
				case 66:
				case 68:
				case 161:
//					double locationLatiude = location.getLatitude();
//					double locationLongitude = location.getLongitude();
					if(mCallback!=null){
						try {
//							JSONObject jsonObject = new JSONObject();
//							jsonObject.put("Latitude", locationLatiude);
//							jsonObject.put("Longitude", locationLongitude);
							mCallback.onSucceedCallback(location);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							mCallback.onErrorCallback(null);
						}
					}
					stopTimeOutTimer();
					stopLocationClient();
				break;
			}
			//GPS信息写入数据库
//			putGPSTodb(location);
		}
		
		public void onReceivePoi(BDLocation poiLocation) {
			if(poiLocation == null)return;
		}
	}
	/**
	 * 开始定位
	 */
	public void startLocationClient(){
		if(mLocationClient != null){
			if(!mLocationClient.isStarted()){
				mLocationClient.getLocOption().setOpenGps(true);
				mLocationClient.start();
			}
			Debuger.logD("获取地理位置:startLocationClient");
		}
	}
	
	/**
	 * 停止定位
	 */
	public void stopLocationClient(){
		if(mLocationClient != null){
			if(isProviderEnabled()){
				mLocationClient.getLocOption().setOpenGps(false);
			}
			mLocationClient.stop();
			Debuger.logD("获取地理位置:stopLocationClient");
		}
	}
	
	/**
	 * 设置相关参数
	 */
	private void setLocationOption(){
		
		LocationClientOption option = new LocationClientOption();
		option.setCoorType("gcj02");			//设置坐标类型
		option.setScanSpan(3600000);				//设置定位模式，小于1秒则一次定位;大于等于1秒则定时定位  设置为1小时，201604需求 by ex-xuyuan001
		option.disableCache(false); 			//true表示禁用缓存定位，false表示启用缓存定位 
		
		if(isProviderEnabled()){
			option.setOpenGps(true);
			option.setPriority(LocationClientOption.GpsFirst);
			option.setIsNeedAddress(true);
		}else{
			option.setPriority(LocationClientOption.NetWorkFirst);
			option.setIsNeedAddress(true);
		}
		
		mLocationClient.setLocOption(option);
	}
	
	public boolean isProviderEnabled(){
		 try {
			 LocationManager locManager = (LocationManager)mContext.getSystemService(Context.LOCATION_SERVICE);
			 if(null == locManager)
			 {
				 return false;
			 }else
			 {
				 return locManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
			 }

		} catch (Exception e) {
			e.printStackTrace();
		} 
		return false;
	}
	
	private void resetTimer(long timeOutDelay){
		if(mTimer!=null){
			mTimer.cancel();
		}
		mTimer = new Timer();
		mTimer.schedule(new TimeOutTimerTask(), timeOutDelay);
	}
	
	
	private void stopTimeOutTimer(){
		if(mTimer!=null){
			mTimer.cancel();
		}
		mTimer = null;
	}
	private class TimeOutTimerTask extends TimerTask {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			stopLocationClient();
			mTimer.cancel();
			mTimer = null;
			if(mCallback!=null){
				try {
					JSONObject jsonObject = new JSONObject();
					int errorCode = 1;
					if(isProviderEnabled()){
						errorCode = 3;
					}
					jsonObject.put("code", errorCode);
					mCallback.onErrorCallback(jsonObject);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					mCallback.onErrorCallback(null);
				}
				
			}
			Debuger.logD("获取地理位置:timout");
			
		}
	}


	public interface LocationCallback {
		/**
		 * 失败回调
		 * @param errorInfo
		 */
		void onErrorCallback(JSONObject errorInfo);
		/**
		 * 成功回调
		 * @param succedInfo
		 */
		void onSucceedCallback(BDLocation succedInfo);
		
	}
	
//	/*
//	 * talkingData 对地理位置的记载
//	 */
//	 public void putGPSTodb(BDLocation location){
//
//	    	GPSLocation gPSLocation = new GPSLocation();
//	    	gPSLocation.setTime(location.getTime());
//	    	gPSLocation.setAltitude(location.getAltitude());
//	    	gPSLocation.setLatitude(location.getLatitude());
//	    	gPSLocation.setLongitude(location.getLongitude());
//
//	    	PADataAgent.onGPSLocation(gPSLocation);
//
//	    }
	
}
