//
//  ALDGetUserLocation.h
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/19.
//  Copyright © 2016年 WQ. All rights reserved.
//

typedef enum {
    GetLocation_Error_None,                  // 没有错误
    GetLocation_Error_Normal,                // 存在错误
} GetLocationErrorType;

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

typedef void(^GetUserLocationBlock)(GetLocationErrorType errorType, NSDictionary *locationDataDic, NSDictionary *errorDic);

@interface ALDGetUserLocation : NSObject

+(ALDGetUserLocation *)shareLocation;  //创建单例

/**
 *  @brief                          获取位置
 *
 *  @param getLocationBlock         block回调
 *  @param block.locationDataDic    经纬度（NSDictionary）
 *  @param block.errorType          GetLocationErrorType
 *  @param block.errorType          错误信息（NSDictionary）
 */
-(void)getUserLocationWithCallBack:(GetUserLocationBlock)getLocationBlock;

@end
