package com.aladdin.component.aldaudiocomponent;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.util.Log;


import com.pingan.aladdin.core.Debuger;

import java.io.IOException;

/**
 * Created by nijinlei on 16/11/14.
 */

public class Media implements IMedia,MediaPlayer.OnPreparedListener,MediaPlayer.OnCompletionListener,MediaPlayer.OnBufferingUpdateListener{
    private static String LOG_TAG = Media.class.getSimpleName();
    private static Media instance;
    private MediaPlayer mediaPlayer;
    private Media(){}

    public static Media getInstance(){
        if(instance == null){
            synchronized (Media.class){
                instance = new Media();
            }
        }
        return instance;
    }

    @Override
    public void mediaPlay(String url) {
        if(mediaPlayer != null){
            mediaPlayer.start();
            return;
        }

        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mediaPlayer.setOnPreparedListener(this);
        mediaPlayer.setOnCompletionListener(this);
        mediaPlayer.setOnBufferingUpdateListener(this);
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(url);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (IOException e) {
            Debuger.logD(e.getMessage());
            mediaPlayer = null;
        }
    }

    @Override
    public void mediaStop() {
        Log.i(LOG_TAG,"mediaStop");
        if(mediaPlayer != null){
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    public void mediaPause() {
        Log.i(LOG_TAG,"mediaPause");
        if(mediaPlayer != null) {
            mediaPlayer.pause();
        }
    }

    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {
        Log.i(LOG_TAG,"onPrepared");
    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        Log.i(LOG_TAG,"onCompletion");
        if(this.mediaPlayer != null){
            mediaStop();
        }
    }

    @Override
    public void onBufferingUpdate(MediaPlayer mediaPlayer, int i) {
        Log.i(LOG_TAG,String.valueOf(i));
    }
}
