//
//  ALDAESComponent.m
//  ALDAESComponent
//
//  Created by xiangyutao on 2017/6/6.
//  Copyright © 2017年 xiangyutao. All rights reserved.
//

#import "ALDAESComponent.h"
#import <CommonCrypto/CommonCryptor.h>
#import "ALDAESCipher.h"


@implementation ALDAESComponent

ALD_Custom_Module(aes)

-(void)encrypt:(ALDJSWebView *)webView :(NSString *)jsonStr :(NSString *)callBack{
    NSDictionary *jsonDic = [jsonStr objectFromJSONString];
    if (!jsonDic) {
        [webView callBack:callBack params:nil err:[ALDError standardError:ALDErrorType_Data_Exception]];
        return;
    }
    
    if (![jsonDic[@"key"]length]) {
        ALDError * errcode = [ALDError customErrorWithCode:@"10018" message:@"参数异常,密钥为空" appIdentifier:nil customParam:nil];
        [webView callBack:callBack params:nil err:errcode];
        return;
    }
    
    if (![jsonDic[@"text"]length]) {
        ALDError * errcode = [ALDError customErrorWithCode:@"10018" message:@"参数异常,需加密字段为空" appIdentifier:nil customParam:nil];
        [webView callBack:callBack params:nil err:errcode];
        return;
    }
    
    if ([jsonDic[@"key"]length]!=16){
        ALDError * errcode = [ALDError customErrorWithCode:@"10018" message:@"参数异常,密钥长度不为16" appIdentifier:nil customParam:nil];
        [webView callBack:callBack params:nil err:errcode];
        return;
    }
    
    size_t  kKeySize =kCCKeySizeAES128;
    NSString *cipherText = aesEncryptString(jsonDic[@"text"],jsonDic[@"key"],kKeySize);
    [webView callBack_Json:callBack  params:@[@{@"message":cipherText}] err:nil];

}

-(void)decrypt:(ALDJSWebView *)webView :(NSString *)jsonStr :(NSString *)callBack{
    NSDictionary *jsonDic = [jsonStr objectFromJSONString];
    if (!jsonDic) {
        [webView callBack:callBack params:nil err:[ALDError standardError:ALDErrorType_Data_Exception]];
        return;
    }
    
    if (![jsonDic[@"key"]length]) {
        ALDError * errcode = [ALDError customErrorWithCode:@"10018" message:@"参数异常,密钥为空" appIdentifier:nil customParam:nil];
        [webView callBack:callBack params:nil err:errcode];
        return;
    }
    
    if (![jsonDic[@"text"]length]) {
        ALDError * errcode = [ALDError customErrorWithCode:@"10018" message:@"参数异常,需加密字段为空" appIdentifier:nil customParam:nil];
        [webView callBack:callBack params:nil err:errcode];
        return;
    }
    
    if ([jsonDic[@"key"]length]!=16){
        ALDError * errcode = [ALDError customErrorWithCode:@"10018" message:@"参数异常,密钥长度不为16" appIdentifier:nil customParam:nil];
        [webView callBack:callBack params:nil err:errcode];
        return;
    }
    
    size_t  kKeySize =kCCKeySizeAES128;
    NSString *decryptText = aesDecryptString(jsonDic[@"text"],jsonDic[@"key"],kKeySize);
    [webView callBack_Json:callBack  params:@[@{@"message":decryptText}] err:nil];

    
}

@end
