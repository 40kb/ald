//
//  ALDOpenBrowse.h
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/21.
//  Copyright © 2016年 WQ. All rights reserved.
//

typedef enum {
    OpenBrowser_Error_None,                  // 没有错误
    OpenBrowser_Error_Normal,                // 存在错误
} OpenBrowserErrorType;

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef void(^OpenBrowserBlock)(OpenBrowserErrorType type, NSDictionary *errorDic);

@interface ALDOpenBrowser : NSObject

/**
 *  @brief                 打开浏览器
 *
 *  @param url             URL
 *  @param callBack        block回调
 *  @param block.type      OpenBrowseErrorType
 *  @param block.errorDic  错误信息
 */
+ (void)openBrowseWithURL:(NSString *)url CallBack:(OpenBrowserBlock )callBack;

@end
