package com.aladdin.component.aldcameracomponent.cameraparam;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aladdin.component.aldcameracomponent.R;


public class PAProgressDialog extends ProgressDialog {

    private LinearLayout mTitleLayout;
    private TextView mTitleTextView;
    private TextView mMsgTextView;
    private int default_width = 278;

    public PAProgressDialog(Context context) {
        super(context);
    }

    public PAProgressDialog(Context context, int theme) {
        super(context, theme);
    }

    public static PAProgressDialog show(Context ctx, int theme) {
        PAProgressDialog d = new PAProgressDialog(ctx, theme);
        d.show();
        return d;
    }

    public static PAProgressDialog show(Context ctx, int theme, String title, String msg) {
        PAProgressDialog d = new PAProgressDialog(ctx, theme);
        d.show();
        d.setTitle(title);
        d.setMessage(msg);
        return d;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.core_dialog_progress);
        Window window = getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.alpha = 0.7f;// 透明度
        lp.dimAmount = 0.3f;// 黑暗度
//        float density = getDensity(getContext());
//        lp.width = (int)(100*density);
        window.setAttributes(lp);
        mTitleLayout = (LinearLayout) findViewById(R.id.progress_topPanel);
        mTitleTextView = (TextView) findViewById(R.id.progress_title);
        mMsgTextView = (TextView) findViewById(R.id.progress_msg);
        mTitleLayout.setVisibility(View.GONE);
        mMsgTextView.setVisibility(View.GONE);
    }

    private float getDensity(Context context) {
        Resources resources = context.getResources();
        DisplayMetrics dm = resources.getDisplayMetrics();
        return dm.density;
    }

    public void setTitle(CharSequence title) {
        if (!TextUtils.isEmpty(title)) {
            mTitleLayout.setVisibility(View.VISIBLE);
            mTitleTextView.setText(title);
        }
    }

    public void setTitle(int titleId) {
        if (titleId != -1) {
            mTitleLayout.setVisibility(View.VISIBLE);
            mTitleTextView.setText(titleId);
        }
    }

    public void setMessage(CharSequence message) {
        if (!TextUtils.isEmpty(message)) {
            mMsgTextView.setVisibility(View.VISIBLE);
            mMsgTextView.setText(message);
        }
    }

    @Override
    public void dismiss() {
        if (getContext() != null && (getContext() instanceof Activity)) {
            if (((Activity) getContext()).isFinishing()) {
                return;
            }
        }
        super.dismiss();
    }

}