//
//  PAClipboradPlugin.m
//  PAiPhoneBank3.0
//
//  Created by 高丙超 on 2016/10/11.
//  Copyright © 2016年 熊剑明. All rights reserved.
//

#import "ALDAlipboradComponent.h"

@implementation ALDAlipboradComponent

ALD_Custom_Module(clipborad);

- (void)copy:(ALDJSWebView *)webView :(NSString *)jsonStr :(NSString *)callBack{
    
    NSDictionary *jsonDic = [ALDConvert objectFromJSONString:jsonStr];
    NSString *realString = jsonDic[@"copyStr"];
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = kCheckNil(realString);
    [webView callBack_Json:callBack params:nil err:NULL];
    
}

- (void)clear:(ALDJSWebView *)webView :(NSString *)callBack{
    
    UIPasteboard * pasteboard  = [UIPasteboard generalPasteboard];
    NSMutableArray *tempItems = [pasteboard.items mutableCopy];
    if (tempItems.count) {
        [tempItems removeAllObjects];
        [pasteboard setItems:tempItems];
    }
    [webView callBack_Json:callBack params:nil err:nil];
}

@end
