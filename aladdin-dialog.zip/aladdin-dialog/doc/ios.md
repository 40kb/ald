# ALDDialogComponent扩展组件接入文档

## aladdin环境配置
Aladdin接入方式详见 <a href='http://10.20.20.177/guide/'>官网</a>。

## 组件下载
组件下载<a href='http://git-ma.paic.com.cn/aladdin-components/aladdin-dialog.git'>仓库地址</a>
</br>

## 接入
### 添加到宿主工程
<image src='images/ALDDialog_01.png'>
 将`ALDDialogComponent.xcodeproj`引入工程
 <image src='images/ALDDialog_02.png'>
  </br>

### 组件工程配置
在`ALDDialogComponent.xcodeproj`的`Build Setting`配置`Framework Search Paths`，路径为`AladdinHybrid.framework和AladdinBase.framework`所在工程的路径。
<image src='images/ALDDialog_03.png'>


### 添加静态库
在主工程中将生成的`libALDDialogComponent.a`添加到工程中
<image src='images/ALDDialog_04.png'>


## 工程的使用及扩展
需要调用Dialog，引入#import `<ALDDialogComponent/ALDDialogComponent.h>`||`<ALDDialog/ALDDialogView.h>`,或者需要对其中的方法进行冲定义，可以重写里面的方法。
<image src='images/ALDDialog_05.png'>

