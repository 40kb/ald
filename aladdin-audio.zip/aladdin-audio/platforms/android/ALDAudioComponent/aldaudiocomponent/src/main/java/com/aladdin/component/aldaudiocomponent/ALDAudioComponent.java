package com.aladdin.component.aldaudiocomponent;

import android.webkit.JavascriptInterface;


import com.pingan.aladdin.core.Debuger;
import com.pingan.aladdin.h5.webview.AladdinWebView;
import com.pingan.aladdin.h5.webview.plugin.HybridComponent;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by nijinlei  on 16/11/14.
 */

public class ALDAudioComponent extends HybridComponent {
    @Override
    public String getName() {
        return "audio";
    }

    @Override
    public boolean isActivityCallbackEnable() {
        return false;
    }

    @JavascriptInterface
    public void play(final AladdinWebView aladdinWebView, String params, final String callback) {
        JSONObject jsonObject;
        String fileName = null;
        try {
            jsonObject = new JSONObject(params);
            fileName = jsonObject.optString("fileName");
        }catch(JSONException e){
            Debuger.logD(e.getMessage());
        }

        Media.getInstance().mediaPlay(fileName);
    }
    @JavascriptInterface
    public void stop(final AladdinWebView aladdinWebView, final String callback) {
        Media.getInstance().mediaStop();
    }

    public void pause(final AladdinWebView aladdinWebView, final String callback) {
        Media.getInstance().mediaPause();
    }
}
