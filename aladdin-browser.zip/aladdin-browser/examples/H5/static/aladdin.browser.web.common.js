/*! aladdin.browser v1.0.0 (c) 2016-2017 Aladdin */
'use strict';

function __$styleInject(css, returnValue) {
  if (typeof document === 'undefined') {
    return returnValue;
  }
  css = css || '';
  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';
  if (style.styleSheet){
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
  head.appendChild(style);
  return returnValue;
}

function Browser(aladdin) {

}

Object.defineProperty(Browser.prototype, 'name', {
    value: 'browser',
    writable: false
});

Browser.prototype.open = function (opts, cb) {
  typeof cb === 'function' && cb();
  var features = "toolbar=no, location=yes, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width=510, height=750";
  window.open(opts.url,"_blank",features);
  return this;
};

module.exports = Browser;
