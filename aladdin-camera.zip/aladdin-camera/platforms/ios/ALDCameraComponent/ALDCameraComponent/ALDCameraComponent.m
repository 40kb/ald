//
//  ALDCamera.m
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/18.
//  Copyright © 2016年 WQ. All rights reserved.
//

#import "ALDCameraComponent.h"
#import "ALDCameraView.h"

@implementation ALDCameraComponent

ALD_Custom_Module(camera);

-(void)getPhotos:(ALDJSWebView *)webView :(NSString *)jsonString :(NSString *)callBack
{
    NSDictionary *jsonDataDic = [jsonString objectFromJSONString];
    
    if (!jsonDataDic) {
        [webView callBack:callBack params:nil err:[ALDError standardError:ALDErrorType_Data_Exception]];
        return;
    }
    
    NSInteger source = [jsonDataDic[@"source"] integerValue];
    NSString *returnType = jsonDataDic[@"returnType"];
    BOOL isEdit = [jsonDataDic[@"edit"] boolValue];
    CGFloat photoWidth = [jsonDataDic[@"width"] floatValue];
    CGFloat photoHeight = [jsonDataDic[@"height"] floatValue];
    CGFloat photoQuality = [jsonDataDic[@"quality"] floatValue];
    NSString *photoType = jsonDataDic[@"type"];
    NSInteger selectMaxNum = [jsonDataDic[@"maxSelect"] integerValue];
    
    ALDCameraView *camera = [ALDCameraView shareCamera];
    [camera getPhotoWithPhotoSource:source EditEnable:isEdit PhotoHeight:photoHeight PhotoWidth:photoWidth PhotoQuality:photoQuality PhotoType:photoType MaxSelectNum:selectMaxNum ReturnType:returnType CallBackBlock:^(CameraErrorType errorType, NSArray *photosArray, NSDictionary *errorDic) {
        if (errorType == Camera_Error_None) {
            //无错误回调
            [webView callBack_Json:callBack params:@[photosArray] err:nil];
        } else if (errorType == Camera_Error_Normal)
        {
            //有错误回调
           ALDError * error = [ALDError customErrorWithCode:@"22000" message:@"相机访问权限未开启" appIdentifier:nil customParam:nil];
            [webView callBack_Json:callBack params:nil err:error];
        } else if (errorType == Photos_Error_Normal)
        {
            //有错误回调
            ALDError * error = [ALDError customErrorWithCode:@"22001" message:@"相册访问权限未开启" appIdentifier:nil customParam:nil];
            [webView callBack_Json:callBack params:nil err:error];
        }
        
    }];
}

@end
