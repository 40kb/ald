/*! aladdin.crypto v1.0.0 (c) 2016-2017 Aladdin */
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('aladdin')) :
	typeof define === 'function' && define.amd ? define(['aladdin'], factory) :
	(global.aladdin = global.aladdin || {}, global.aladdin.crypto = factory(global.aladdin));
}(this, (function (aladdin) { 'use strict';

aladdin = 'default' in aladdin ? aladdin['default'] : aladdin;

function readonlyProperty(obj, name, value) {
  Object.defineProperty(obj, name, {
    value: value,
    writable: false
  });
}

function Crypto(aladdin$$1) {
  this._aladdin = aladdin$$1;
}

readonlyProperty(Crypto.prototype, 'name', 'crypto');

/**
 * 根据指定的加密类型，加密源字符，返回加密后的字符（RSA | DES 所需的秘钥，全部由Native维护,H5不介入）
 *
 * @param {Object} opts
 * @param {Function} cb
 * @returns this
 */
Crypto.prototype.encrypt = function(opts, cb) {
  opts = opts || {};
  this._aladdin.call(this.name, 'encrypt', opts, cb);
  return this;
};

/**
 * 根据指定的解密类型，解密源字符，返回加密前的字符(注意：不支持MD5方式解密，RSA | DES 所需的秘钥，全部由Native维护,H5不介入)
 *
 * @param {Object} opts
 * @param {Function} cb
 * @returns this
 */
Crypto.prototype.decrypt = function(opts, cb) {
  opts = opts || {};
  this._aladdin.call(this.name, 'decrypt', opts, cb);
  return this;
};

aladdin.use(Crypto);

var aladdin_crypto = aladdin.crypto;

return aladdin_crypto;

})));
