const fs = require('fs');
const rollup = require('rollup');
const uglify = require('uglify-js');
const uglifycss = require('uglifycss');
const buble = require('rollup-plugin-buble');
const replace = require('rollup-plugin-replace');
const postcss = require('rollup-plugin-postcss');
const commonjs = require('rollup-plugin-commonjs');
const nodeResolve = require('rollup-plugin-node-resolve');
const ora = require('ora');
const path = require('path');
let {
  name,
  version
} = require('./package.json');

name = name.replace(/^aladdin-/, '');

const distDir = path.resolve(__dirname, './dist');
const srcDir = __dirname + '/src';

const banner = '/*! aladdin.' + name + ' v' + version + ' (c) 2016-' + new Date().getFullYear() + ' Aladdin */';
const format = 'umd';

const spinner = ora('building...').start();

Promise.all([
    packaging(srcDir + '/aladdin.' + name + '.js', 'aladdin.' + name, false, false),
    packaging(srcDir + '/aladdin.' + name + '.web.js', 'aladdin.' + name + '.web', false, true)
  ])
  .catch(function(err) {
    spinner.fail(JSON.stringify(err));
  });

function packaging(entry, output, usePostcss, useResolve) {

  return rollup.rollup({
      entry: entry,
      external: ['aladdin'],
      plugins: [
        usePostcss && postcss({
          plugins: [],
          extensions: ['.css']
        }),
        buble(),
        useResolve && nodeResolve({
          jsnext: true,
          main: true,
          browser: true
        }),
        useResolve && commonjs()
      ]
    })
    .then(function(bundle) {
      const code = bundle.generate({
        format: format,
        banner: banner,
        moduleName: 'aladdin.' + name,
        external: ['aladdin'],
        globals: {
          aladdin: 'aladdin'
        }
      }).code;

      const res = uglify.minify(code, {
        fromString: true,
        output: {
          preamble: banner,
          ascii_only: true
        }
      });
      return [
        write(path.join(distDir, output + '.js'), code),
        write(path.join(distDir, output + '.min.js'), res.code),
      ];
    });
}

function write(dist, code) {
  return new Promise(function(resolve, reject) {
    fs.writeFile(dist, code, function(err) {
      if (err) return reject(err);
      spinner.succeed(blue(dist) + ' ' + getSize(code));
      resolve();
    });
  });
}

function getSize(code) {
  return (code.length / 1024).toFixed(2) + 'kb';
}

function onerror(e) {
  console.log(e);
}

function blue(str) {
  return '\x1b[1m\x1b[34m' + str + '\x1b[39m\x1b[22m';
}