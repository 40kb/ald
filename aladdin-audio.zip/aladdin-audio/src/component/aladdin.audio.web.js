'use strict';

function Audio() {}

Object.defineProperty(Audio.prototype, 'name', {
  value: 'audio',
  writable: false
});

/**
 * 音频播放开始
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Audio.prototype.play = function(opts, cb) {

  opts = opts || {};
  cb = typeof cb === 'function' ? cb : function() {};

  var audioElem = this.audioElem;
  if (typeof opts.fileName !== 'string') { //播放路径不存在
    if (audioElem) {
      opts.fileName = audioElem.src;
    } else {
      cb({
        code: '' //播放地址不存在
      });
      return this;
    }
  }

  /**
   * 已经存在,播放文件是同一个,则认为是继续播放
   */
  if (audioElem && audioElem.src == opts.fileName) {
    audioElem.play();
  } else {
    audioElem && this.stop();

    audioElem = this.audioElem = document.createElement('audio');
    audioElem.src = opts.fileName;
    audioElem.play();
  }

  audioElem.onplaying = function() {
    audioElem.onplaying = null;
    cb();
  };
  audioElem.onerror = function() {
    audioElem.onerror = null;
    cb({
      code: '' //播放地址不存在
    });
  };
  return this;
};

/**
 * 音频播放停止
 *
 * @param {Function} cb
 */
Audio.prototype.stop = function(cb) {
  cb = typeof cb === 'function' ? cb : function() {};

  var audioElem = this.audioElem;
  if (audioElem) {
    audioElem.pause();
    audioElem.onerror = null; //资源src置空后会报错，不执行回调
    audioElem.onplaying = null;
    audioElem.src = '';

    cb();
  } else {
    cb({
      code: ''
    });
  }


  return this;
};

/**
 * 音频播放暂停
 *
 * @param {Function} cb
 */
Audio.prototype.pause = function(cb) {
  cb = typeof cb === 'function' ? cb : function() {};

  var audioElem = this.audioElem;
  if (!audioElem) {
    cb({
      code: ''
    });
    return;
  }

  audioElem.onpause = function() {
    audioElem.onpause = null;
    cb();
  };
  audioElem.onerror = function() {
    audioElem.onerror = null;
    cb({
      code: ''
    });
  };
  audioElem.pause();

  return this;
};

export default Audio;