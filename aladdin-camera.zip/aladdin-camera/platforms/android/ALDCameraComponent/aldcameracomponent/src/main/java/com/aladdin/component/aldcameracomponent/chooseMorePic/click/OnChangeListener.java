package com.aladdin.component.aldcameracomponent.chooseMorePic.click;



public interface OnChangeListener {
    void OnChangeListener(int position, boolean isChecked);
}
