package com.aladdin.component.alddialogcomponent;

import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;


import com.pingan.aladdin.core.exception.CallbackNotNullException;
import com.pingan.aladdin.core.resource.metaData.ResourceMetaDataMananger;
import com.pingan.aladdin.h5.webview.AladdinWebView;
import com.pingan.aladdin.h5.webview.plugin.AladdinJSExecutor;
import com.pingan.aladdin.h5.webview.plugin.HybridComponent;

import org.json.JSONObject;


/**
 * 进度
 */
public class ALDDialogComponent extends HybridComponent {

    private static Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public String getName() {
        return "dialog";
    }

    @Override
    public boolean isActivityCallbackEnable() {
        return false;
    }

    @JavascriptInterface
    public void confirm(final AladdinWebView webView, JSONObject jsonObject, final String callBack) {

        final DialogParam dialogParam = (DialogParam) ResourceMetaDataMananger.getResult(jsonObject, DialogParam.class);
        handler.post(new Runnable() {
            @Override
            public void run() {
                DialogHelper.confirm(getContext(webView), dialogParam.getTitle(), dialogParam.getMessage(), dialogParam.getRightButtonText(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       try {
                           AladdinJSExecutor.callStringToJS(webView, dialogParam.getRightButtonCallback(), null, null);
                       }catch (Exception e){
                           e.printStackTrace();
                       }
                    }
                }, dialogParam.getLeftButtonText(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            AladdinJSExecutor.callStringToJS(webView, dialogParam.getLeftButtonCallback(), null, null);
                        }catch (Exception e){
                            e.printStackTrace();
                        }

                    }
                });
            }
        });
    }

    @JavascriptInterface
    public void alert(final AladdinWebView webView,String msg, final String callback) {
//
        final AlertParam alertParam = (AlertParam) ResourceMetaDataMananger.getResult(msg, AlertParam.class);
        handler.post(new Runnable() {
            @Override
            public void run() {
                DialogHelper.alert(getContext(webView), alertParam.getTitle(), alertParam.getButtonText(), alertParam.getMessage(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            AladdinJSExecutor.callStringToJS(webView, alertParam.getButtonCallback(), null, null);
                        } catch (CallbackNotNullException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
    }


}
