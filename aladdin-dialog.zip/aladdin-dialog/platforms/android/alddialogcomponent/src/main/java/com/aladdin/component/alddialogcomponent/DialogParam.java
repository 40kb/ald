package com.aladdin.component.alddialogcomponent;

/**
 * Created by ouyangxingyu198 on 16/7/19.
 */
public class DialogParam {

    private String title;
    private  String message;
    private String leftButtonText="确定";
    private String leftButtonCallback;
    private String rightButtonText="取消";
    private String rightButtonCallback;

    @Override
    public String toString() {
        return "DialogParam{" +
                "title='" + title + '\'' +
                ", onMessage='" + message + '\'' +
                ", leftButtonText='" + leftButtonText + '\'' +
                ", leftButtonCallback='" + leftButtonCallback + '\'' +
                ", rightButtonText='" + rightButtonText + '\'' +
                ", rightButtonCallback='" + rightButtonCallback + '\'' +
                '}';
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getLeftButtonText() {
        return leftButtonText;
    }

    public void setLeftButtonText(String leftButtonText) {
        this.leftButtonText = leftButtonText;
    }

    public String getLeftButtonCallback() {
        return leftButtonCallback;
    }

    public void setLeftButtonCallback(String leftButtonCallback) {
        this.leftButtonCallback = leftButtonCallback;
    }

    public String getRightButtonText() {
        return rightButtonText;
    }

    public void setRightButtonText(String rightButtonText) {
        this.rightButtonText = rightButtonText;
    }

    public String getRightButtonCallback() {
        return rightButtonCallback;
    }

    public void setRightButtonCallback(String rightButtonCallback) {
        this.rightButtonCallback = rightButtonCallback;
    }
}
