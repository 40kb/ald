package com.aladdin.component.aldalipboradcomponent;

import android.text.TextUtils;
import android.webkit.JavascriptInterface;
import android.widget.TextView;

import com.pingan.aladdin.core.Debuger;
import com.pingan.aladdin.core.exception.CallbackNotNullException;
import com.pingan.aladdin.core.exception.errorManager.AladdinErrorMessage;
import com.pingan.aladdin.core.resource.metaData.ResourceMetaDataMananger;
import com.pingan.aladdin.h5.webview.AladdinWebView;
import com.pingan.aladdin.h5.webview.plugin.AladdinJSExecutor;
import com.pingan.aladdin.h5.webview.plugin.HybridComponent;


import org.json.JSONObject;

/**
 * @author ex-yangzhenxing001@pingan.com.cn
 * @date 2016/10/11
 */
public class ALDAlipboradComponent extends HybridComponent {
    @Override
    public String getName() {
        return "clipboard";
    }

    @Override
    public boolean isActivityCallbackEnable() {
        return false;
    }

    @JavascriptInterface
    public void copy(final AladdinWebView aladdinWebView, JSONObject params, String callback) {

//        String copyStr = params.optString("text");
        ClipBoardParm clipBoardParm = (ClipBoardParm)ResourceMetaDataMananger.getResult(params,ClipBoardParm.class);
        String copyStr = clipBoardParm.getText();
        try {
            if (!TextUtils.isEmpty(copyStr)) {

                ClipBoardManager.copy(aladdinWebView.getContext(), copyStr);
                AladdinJSExecutor.callStringToJS(aladdinWebView, callback, null, null);

            } else {
                AladdinJSExecutor.callStringToJS(aladdinWebView, callback, null, AladdinErrorMessage.build(33001, "copy content is empty"));
            }
        } catch (CallbackNotNullException e) {
            Debuger.logD(e.getMessage());
        }
    }

    @JavascriptInterface
    public void paste(final AladdinWebView aladdinWebView, final String callback) {
        String content = ClipBoardManager.read(aladdinWebView.getContext());
        try {
            AladdinJSExecutor.callStringToJS(aladdinWebView, callback, content, null);
        } catch (CallbackNotNullException e) {
            Debuger.logD(e.getMessage());
        }
    }

    @JavascriptInterface
    public void clear(final AladdinWebView aladdinWebView, final String callback) {
        try {
            ClipBoardManager.clear(aladdinWebView.getContext());
            AladdinJSExecutor.callStringToJS(aladdinWebView, callback, null, null);
        } catch (CallbackNotNullException e) {
            Debuger.logD(e.getMessage());
        }
    }
}
