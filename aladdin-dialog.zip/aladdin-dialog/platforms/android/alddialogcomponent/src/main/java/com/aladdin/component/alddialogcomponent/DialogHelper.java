package com.aladdin.component.alddialogcomponent;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.pingan.aladdin.core.utils.StringUtil;


/**
 * 对话框
 */
public class DialogHelper {


    public static void confirm(Context context, String title,String content,String leftButton,
                                         DialogInterface.OnClickListener leftCallback,String rightButton,DialogInterface.OnClickListener rightCallback) {
        if(StringUtil.isEmpty(leftButton)){
            leftButton = context.getResources().getString(android.R.string.cancel);
        }
        if(StringUtil.isEmpty(rightButton)){
            rightButton = context.getResources().getString(android.R.string.ok);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(content);
        builder.setTitle(title);
        builder.setPositiveButton(rightButton, rightCallback);
        builder.setNegativeButton(leftButton, leftCallback);
        builder.create().show();
    }

    public static void alert(Context context,String title,String fixText, String content,DialogInterface.OnClickListener callback) {
        if(StringUtil.isEmpty(fixText)){
            fixText = context.getResources().getString(android.R.string.ok);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(content);
        builder.setTitle(title);
        builder.setPositiveButton(fixText,callback);
        builder.create().show();
    }

    public static void alert(Context context,String title,String fixText, String content,boolean isCancel,DialogInterface.OnClickListener callback) {
        if(StringUtil.isEmpty(fixText)){
            fixText = context.getResources().getString(android.R.string.ok);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(content);
        builder.setTitle(title);
        builder.setPositiveButton(fixText,callback);
        AlertDialog dialog = builder.create();
        dialog.setCancelable(isCancel);
        dialog.setCanceledOnTouchOutside(isCancel);
        dialog.show();
    }


}
