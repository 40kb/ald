/*! aladdin.audio v1.0.0 (c) 2016-2017 Aladdin */
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('aladdin')) :
	typeof define === 'function' && define.amd ? define(['aladdin'], factory) :
	(global.aladdin = global.aladdin || {}, global.aladdin.audio = factory(global.aladdin));
}(this, (function (aladdin) { 'use strict';

aladdin = 'default' in aladdin ? aladdin['default'] : aladdin;

function Audio(aladdin$$1) {
  this._aladdin = aladdin$$1;
}

Object.defineProperty(Audio.prototype, 'name', {
  value: 'audio',
  writable: false
});

/**
 * 音频播放开始
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Audio.prototype.play = function(opts, cb) {
  opts = opts || {};

  return this._aladdin.call(this.name, 'play', opts, cb);
};

/**
 * 音频播放停止
 *
 * @param {Function} cb
 */
Audio.prototype.stop = function(cb) {
  return this._aladdin.call(this.name, 'stop', cb);
};

/**
 * 音频播放暂停
 *
 * @param {Function} cb
 */
Audio.prototype.pause = function(cb) {
  return this._aladdin.call(this.name, 'pause', cb);
};

aladdin.use(Audio);

var index = aladdin.audio;

return index;

})));
