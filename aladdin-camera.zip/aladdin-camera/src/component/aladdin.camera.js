'use strict';

function Camera(aladdin) {
  this._aladdin = aladdin;
}

Object.defineProperty(Camera.prototype, 'name', {
  value: 'camera',
  writable: false
});

/**
 * 获取照片
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Camera.prototype.getPhotos = function(opts, cb) {
  opts = opts || {};

  this._aladdin.call(this.name, 'getPhotos', opts, cb);

  return this;
};

/**
 * 检测前置摄像头是否开启
 * （安卓需检测是否可用）
 *
 * @param {Object} opts
 * @param {Function} cb
 */
Camera.prototype.getFrontCameraState = function(cb) {
  this._aladdin.call(this.name, 'getFrontCameraState', cb);
  return this;
};

export default Camera;