import aladdin from 'aladdin';
import Dialog from './component/aladdin.dialog';

aladdin.use(Dialog, 'dialog');

export default aladdin.dialog