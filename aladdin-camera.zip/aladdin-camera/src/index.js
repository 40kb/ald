import aladdin from 'aladdin';
import Camera from './component/aladdin.camera';

aladdin.use(Camera);

export default aladdin.camera;

