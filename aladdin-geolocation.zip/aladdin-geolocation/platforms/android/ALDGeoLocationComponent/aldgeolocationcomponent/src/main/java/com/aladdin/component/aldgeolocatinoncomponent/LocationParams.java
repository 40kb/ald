package com.aladdin.component.aldgeolocatinoncomponent;

/**
 * @author ex-yangzhenxing001@pingan.com.cn
 * @date 2016/10/9
 */
public class LocationParams {
    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";
    public static final String POI = "poi";
    public static final String ADDR = "addr";
}
