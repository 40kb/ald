//
//  ALDBrowse.m
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/21.
//  Copyright © 2016年 WQ. All rights reserved.
//

#import "ALDBrowserComponent.h"
#import "ALDOpenBrowser.h"

@implementation ALDBrowserComponent

ALD_Custom_Module(browser);

- (void)open:(ALDJSWebView *)webView :(NSString *)json :(NSString *)callBack
{
    NSDictionary *jsonDic = [json objectFromJSONString];
    
    if (!jsonDic) {
        ALDError * errcode = [ALDError customErrorWithCode:@"10018" message:@"参数异常" appIdentifier:nil customParam:nil];
        [webView callBack:callBack params:nil err:errcode];
        return;
    }
    
    NSString *url = jsonDic[@"url"];
    
    if (url.length<=0) // URL adress empty
    {
        ALDError * errcode = [ALDError customErrorWithCode:@"10018" message:@"url参数异常,不能为空" appIdentifier:nil customParam:nil];
        [webView callBack:callBack params:nil err:errcode];
        return;
    }
    
    
    [ALDOpenBrowser openBrowseWithURL:url CallBack:^(OpenBrowserErrorType type, NSDictionary *errorDic) {
        if (type == OpenBrowser_Error_None ) {
            //成功回调
            [webView callBack_Json:callBack params:nil err:nil];
        } else
        {
            //失败回调
            ALDError * errcode = [ALDError customErrorWithCode:@"21100" message:@"url无效" appIdentifier:nil customParam:nil];
            [webView callBack:callBack params:nil err:errcode];
        }
        
    }];
}

@end
