import aladdin from 'aladdin';
import Camera from './component/aladdin.camera.web';

aladdin.use(Camera);

export default aladdin.camera;