//
//  PAEBOpenWallet.h
//  PAEBank
//
//  Created by insigmaMAC on 2017/4/6.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import <AladdinHybrid/AladdinHybrid.h>

@interface ALDApplePayComponent : ALDHybridBridge

/**
 调用applePay
 
 @param webView webView description
 @param callBack callBack description
 */
-(void)openWallet:(ALDJSWebView*)webView :(NSString*)callBack;

@end
