//
//  ALDGetUserLocation.m
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/19.
//  Copyright © 2016年 WQ. All rights reserved.
//

//判断系统版本
#define IOS8_OR_LATER   ([[[UIDevice currentDevice] systemVersion] doubleValue]>=8.0)

#define KeyWindow   [UIApplication sharedApplication].keyWindow

#define LatitudeKey                 @"latitude"               /**< 纬度 */
#define LongitudeKey                @"longitude"              /**< 经度 */

/**< 错误回调的key */
#define CodeKey                     @"code"
#define MessageKey                  @"message"

/**< 未开启定位服务 */
#define ClossLocationServer         @21700
/**< 未授权应用访问定位功能 */
#define CallLocationServerFailure   @21701

#import "ALDGetUserLocation.h"

@interface ALDGetUserLocation ()<CLLocationManagerDelegate>

@property (nonatomic, copy) GetUserLocationBlock  getCurrentLocationBlock;    /**< 回调 */
@property (nonatomic, strong) CLLocationManager *locationManager;     /**< 位置管理 */
@property (nonatomic,strong) UIAlertView * alertview;
@end
@implementation ALDGetUserLocation

+(ALDGetUserLocation *)shareLocation
{
    static ALDGetUserLocation *getUserLocation;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        getUserLocation = [[ALDGetUserLocation alloc] init];
    });
    return getUserLocation;
}
-(void)getUserLocationWithCallBack:(GetUserLocationBlock)getLocationBlock
{
    _getCurrentLocationBlock = getLocationBlock;
    //判断定位服务是否可用
    if ([CLLocationManager locationServicesEnabled]) {
        if (_locationManager) {
            _locationManager.delegate = nil;
            _locationManager = nil;
        }
        _locationManager = [[CLLocationManager alloc] init];
        if (IOS8_OR_LATER) {
            [_locationManager requestWhenInUseAuthorization];
        }
        _locationManager.delegate = self;
        //设置地位距离过滤参数（当本次定位于上次点位之间的距离大于或等于这个值时，调用代理方法）
        _locationManager.distanceFilter = 100;
        //定位精度
        _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        //开始更新位置
        [_locationManager startUpdatingLocation];
    } else
    {
        //未开启定位服务回调
        _getCurrentLocationBlock(GetLocation_Error_Normal,nil,@{CodeKey:ClossLocationServer,MessageKey:@"未开启定位服务，请在“设置-隐私-定位服务”中开启定位服务功能。"});
    }
}

//提醒用户设置访问权限
-(void)showAlertViewWithTitle:(NSString *)title Message:(NSString *)message {
    if (IOS8_OR_LATER) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [alertController addAction:cancelAction];
        
        [KeyWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
    } else {
        if (_alertview) {
            [_alertview dismissWithClickedButtonIndex:0 animated:NO];
            _alertview = nil;
        }
        _alertview = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [_alertview show];
    }
}


#pragma mark - CLLocationManagerDelegate
//获取到新的位置
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    [manager stopUpdatingLocation];
    CLLocation *location = [locations firstObject];
   //拼接经纬度
    NSDictionary *locationDic = @{LatitudeKey:@(location.coordinate.latitude),LongitudeKey:@(location.coordinate.longitude)};
    //回调
    if (_getCurrentLocationBlock) {
        _getCurrentLocationBlock(GetLocation_Error_None,locationDic,nil);
    }

}

//无法获取位置
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    [manager stopUpdatingLocation];
    
    if ([error code] == kCLAuthorizationStatusRestricted || [error code] == kCLAuthorizationStatusDenied) {
        //未授权应用访问定位功能
        if (_getCurrentLocationBlock) {
             _getCurrentLocationBlock(GetLocation_Error_Normal,nil,@{CodeKey:CallLocationServerFailure,MessageKey:@"未授权应用访问定位功能 \n 请在“设置-隐私-定位服务”选项中，允许本应用访问您的位置信息。"});
        }
    }
}

@end
