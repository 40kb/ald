import aladdin from 'aladdin';
import Geolocation from './component/aladdin.geolocation.web';

aladdin.use(Geolocation, 'geolocation');

export default aladdin.geolocation;