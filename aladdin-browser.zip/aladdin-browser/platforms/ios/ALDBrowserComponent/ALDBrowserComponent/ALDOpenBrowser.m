//
//  ALDOpenBrowse.m
//  ALADDINModuleDemo
//
//  Created by WQ on 16/7/21.
//  Copyright © 2016年 WQ. All rights reserved.
//

#import "ALDOpenBrowser.h"

@implementation ALDOpenBrowser

+ (void)openBrowseWithURL:(NSString *)url CallBack:(OpenBrowserBlock)callBack
{
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:url]]) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
        if (callBack) {
            //成功回调
            callBack(OpenBrowser_Error_None,nil);
        }
    } else
    {
        if (callBack) {
            callBack(OpenBrowser_Error_Normal, nil);
        }
    }
}

@end
