package com.aladdin.component.aldbrowsercomponent;

/**
 * Created by ouyangxingyu198 on 16/7/25.
 */
public class BrowserParam {

    private String url;

    public BrowserParam(String url) {
        this.url = url;
    }

    public BrowserParam() {
    }

    @Override
    public String toString() {
        return "browserParam{" +
                "url='" + url + '\'' +
                '}';
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
