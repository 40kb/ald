package com.aladdin.component.aldcameracomponent;

/**
 * Created by micro on 16/7/21.
 */
public class CameraParam {
    /**
     * 默认照片来源(1:拍照 ,2:相册 )
     */
    private int source = 1;
    /**
     * 返回的照片类型( uri| base64)
     */
    private String returnType;
    /**
     * 选取照片后是否编辑
     */
    private boolean edit;
    /**
     * 照片宽度(单位 px,默认照片宽度)
     */
    private int width;
    /**
     * 照片高度(单位 px,默认照片高度度)
     */
    private int height;
    /**
     * 照片质量( 1-100,默认为原图)
     */
    private int quality;
    /**
     * 照片类型( jpg| png,默认为 jpg)
     */
    private String type;
    private int maxSelect;

    public CameraParam() {
    }

    public com.aladdin.component.aldcameracomponent.cameraparam.CameraParam getCameraParam(){
        com.aladdin.component.aldcameracomponent.cameraparam.CameraParam  cameraParam = new com.aladdin.component.aldcameracomponent.cameraparam.CameraParam ();

        cameraParam.setSource(this.source);
        cameraParam.setReturnType(this.returnType);
        cameraParam.setEdit(this.edit);
        cameraParam.setWidth(this.width);
        cameraParam.setHeight(this.height);
        cameraParam.setQuality(this.quality);
        cameraParam.setType(this.type);
        cameraParam.setMaxSelect(this.maxSelect);

        return cameraParam;
    }

    public int getSource() {
        return this.source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public String getReturnType() {
        return this.returnType;
    }

    public void setReturnType(String returnType) {
        this.returnType = returnType;
    }

    public boolean isEdit() {
        return this.edit;
    }

    public void setEdit(boolean edit) {
        this.edit = edit;
    }

    public int getWidth() {
        return this.width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getQuality() {
        return this.quality;
    }

    public void setQuality(int quality) {
        this.quality = quality;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getMaxSelect() {
        return this.maxSelect;
    }

    public void setMaxSelect(int maxSelect) {
        this.maxSelect = maxSelect;
    }

    public String toString() {
        return "CameraParam{source=\'" + this.source + '\'' + ", returnType=\'" + this.returnType + '\'' + ", edit=" + this.edit + ", width=" + this.width + ", height=" + this.height + ", quality=" + this.quality + ", type=" + this.type + ", maxSelect=" + this.maxSelect + '}';
    }
}
