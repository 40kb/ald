export default function readonlyProperty(obj, name, value) {
  Object.defineProperty(obj, name, {
    value: value,
    writable: false
  });
};
