package com.aladdin.component.aldcameracomponent.cameraparam;

import com.pingan.aladdin.core.exception.errorManager.AladdinErrorMessage;

import org.json.JSONObject;

import java.util.LinkedList;

/**
 * 相机相册完成回调
 */
public interface CameraCallback {
    void onCameraComplete(int code, AladdinErrorMessage message, String data);
    void onMaxCameraComplete(int code, AladdinErrorMessage message, LinkedList<JSONObject> data);
}
