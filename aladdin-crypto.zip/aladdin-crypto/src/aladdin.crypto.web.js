'use strict';
import aladdin from 'aladdin';
import readonlyProperty from './util/readonlyProperty';
import nextTick from './util/nextTick';
import {
  required
} from './util/validate';
import RSAKey from './web/rsa';
import SM2 from './web/union-sm2-min-1.0';
import CryptoJS from 'crypto-js';

function Crypto(aladdin) {

}

readonlyProperty(Crypto.prototype, 'name', 'crypto');

Crypto.prototype.encryptSync = function(opts) {
  required('opts', opts, 'object');
  required('opts.params', opts.params, 'object');

  var result = '';
  var params = opts.params;

  switch (opts.mode) {
    case 'MD5':
      result = CryptoJS.MD5(opts.source).toString();
      if (params.length === '16') {
        result = result.substr(8, 16);
      }
      break;
    case 'SHA1':
      result = CryptoJS.SHA1(opts.source).toString();
      break;
    case 'SHA256':
      result = CryptoJS.SHA256(opts.source).toString();
      break;
    case '3DES':
      var key = CryptoJS.enc.Utf8.parse(params.secretKey);
      var encrypted = CryptoJS.TripleDES.encrypt(opts.source, key, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
      });
      result = encrypted.toString();
      break;
    case 'AES':
      var aesKey = CryptoJS.enc.Utf8.parse(params.secretKey);
      var aseEncrypted = CryptoJS.AES.encrypt(opts.source, aesKey, {
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
      });
      result = aseEncrypted.toString();
      break;
    case 'RSA':
      var RSA = new RSAKey();
      RSA.setPublic(params.secretKeyN, params.secretKeyE);
      result = RSA.encrypt(opts.source);
      break;
    case 'SM2':
      var textData = SM2.CryptoJS.enc.Utf8.parse(opts.source);
      var cipherMode = params.cipherMode || SM2.SM2CipherMode.C1C3C2;
      var cipher = new SM2.SM2Cipher(cipherMode);
      var userKey = cipher.CreatePoint(params.secretKeyX, params.secretKeyY);
      var msgData = cipher.GetWords(textData.toString());
      result = cipher.Encrypt(userKey, msgData);
      break;
  }
  return result;
};

Crypto.prototype.encrypt = function(opts, cb) {
  const result = this.encryptSync(opts);
  typeof cb === 'function' && nextTick(() => {
    cb(null, result);
  });
  return this;
};

Crypto.prototype.decryptSync = function(opts) {
  required('opts', opts, 'object');
  required('opts.params', opts.params, 'object');

  let result = '';
  if (opts.mode === '3DES' && opts.params.secretKey) {
    const key = CryptoJS.enc.Utf8.parse(opts.params.secretKey);
    const decrypted = CryptoJS.TripleDES.decrypt(opts.source, key, {
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7
    });
    result = CryptoJS.enc.Utf8.stringify(decrypted);
  }
  return result;
};

Crypto.prototype.decrypt = function(opts, cb) {
  const result = this.decryptSync(opts);
  typeof cb === 'function' && nextTick(() => {
    cb(null, result);
  });
  return this;
};

aladdin.use(Crypto);

export default aladdin.crypto;