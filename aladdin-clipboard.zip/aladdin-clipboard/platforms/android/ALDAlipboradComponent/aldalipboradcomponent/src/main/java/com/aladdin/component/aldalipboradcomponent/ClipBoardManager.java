package com.aladdin.component.aldalipboradcomponent;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;

import static android.content.Context.CLIPBOARD_SERVICE;

/**
 * @author ex-yangzhenxing001@pingan.com.cn
 * @date 2016/9/27
 */
public class ClipBoardManager {


    public static String read(Context context) {
        ClipboardManager manager = (ClipboardManager) context.getSystemService(CLIPBOARD_SERVICE);
        if (manager.hasPrimaryClip() && manager.getPrimaryClipDescription().hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) {
            if (null != manager.getPrimaryClip().getItemAt(0).getText()) {
                return manager.getPrimaryClip().getItemAt(0).getText().toString();
            }
        }
        return null;
    }


    public static void copy(Context context, String content) {
        ClipboardManager c = (ClipboardManager) context.getSystemService(CLIPBOARD_SERVICE);
        ClipData myClip = ClipData.newPlainText(null, content);
        c.setPrimaryClip(myClip);
    }


    public static void clear(Context context) {
        copy(context, null);
    }
}
