# ALDAlipboradComponent扩展组件接入文档

## aladdin环境配置
Aladdin接入方式详见 <a href='http://10.20.20.177/guide/'>官网</a>。

## 组件下载
组件下载<a href='http://git-ma.paic.com.cn/aladdin-components/aladdin-clipboard.git'>仓库地址</a>
</br>

## 接入
### 添加到宿主工程
<image src='images/clipboard_01.png'>
 将`ALDAlipboradComponent.xcodeproj`引入工程
 <image src='images/clipboard_02.png'>
  </br>

### 组件工程配置
在`ALDAlipboradComponent.xcodeproj`的`Build Setting`配置`Framework Search Paths`，路径为`AladdinHybrid.framework和AladdinBase.framework`所在工程的路径。
<image src='images/clipboard_03.png'>


### 添加工程引用
在主工程中将生成的`libALDAlipboradComponent.a`添加到工程中
<image src='images/clipboard_04.png'>


## 工程的使用及扩展
需要调用Browser，引入#import `<ALDAlipboradComponent/ALDAlipboradComponent.h>`或者需要对其中的方法进行冲定义，可以重写里面的方法。
<image src='images/clipboard_05.png'>

