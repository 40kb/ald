'use strict';

function Geolocation(aladdin) {

}

Object.defineProperty(Geolocation.prototype, 'name', {
    value: 'geolocation',
    writable: false
});

var errorMsg = ['尝试获取您的位置信息时发生错误', '用户拒绝了获取位置信息请求', '浏览器无法获取您的位置信息', '获取您位置信息超时'];

Geolocation.prototype.getCurrentPosition = function (cb) {
  if (typeof cb !== 'function') {
    return this;
  }
  if (navigator.geolocation) { // 支持
    navigator.geolocation.getCurrentPosition(function (position) {
      cb(null, {
        latitude:position.coords.latitude,
        longitude:position.coords.longitude
      });
    }, function (error) {
      cb({
        code: error.code,
        message: errorMsg[error.code] || '未知错误'
      }, null);
    });
  }
  return this;
};

export default Geolocation;
