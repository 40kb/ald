package com.aladdin.component.aldcameracomponent.chooseMorePic.click;


import android.view.View;

public interface OnImageDirItemListener {
    void onImageDirItemListener(View view, int position);
}
