/*! aladdin.browser v1.0.0 (c) 2016-2017 Aladdin */
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory(require('aladdin')) :
	typeof define === 'function' && define.amd ? define(['aladdin'], factory) :
	(global.aladdin = global.aladdin || {}, global.aladdin.browser = factory(global.aladdin));
}(this, (function (aladdin) { 'use strict';

aladdin = 'default' in aladdin ? aladdin['default'] : aladdin;

function Browser(aladdin$$1) {

}

Object.defineProperty(Browser.prototype, 'name', {
    value: 'browser',
    writable: false
});

Browser.prototype.open = function (opts, cb) {
  typeof cb === 'function' && cb();
  var features = "toolbar=no, location=yes, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width=510, height=750";
  window.open(opts.url,"_blank",features);
  return this;
};

aladdin.use(Browser);

var index_web = aladdin.browser;

return index_web;

})));
