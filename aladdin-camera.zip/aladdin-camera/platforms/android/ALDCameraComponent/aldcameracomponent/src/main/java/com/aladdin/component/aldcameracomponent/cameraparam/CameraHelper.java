package com.aladdin.component.aldcameracomponent.cameraparam;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;

/**
 * 相机相册组件功能
 */
public class CameraHelper {


    public CameraHelper() {

    }


    /**
     * 拍照
     */
    public static void camera(Activity activity, Uri savePath, int request_code) {
        Intent getImageByCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        getImageByCamera.putExtra(MediaStore.EXTRA_OUTPUT, savePath);
        activity.startActivityForResult(getImageByCamera, request_code);
    }

    /**
     * 相册
     */
    public static void album(Activity activity, int request_code) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        activity.startActivityForResult(intent, request_code);
    }

    /**
     * 从相册截图
     *
     * @param width  宽度
     * @param height 高度
     * @param uri    保存路径
     */
    public static void cropPick(Activity activity, int width, int height, Uri uri, int request_code) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_PICK);
        intent.setType("image/*");
        intent.putExtra("crop", "true");
        if (width > 0) {
            intent.putExtra("outputX", width);
        } else {
            intent.putExtra("outputX", 150);
            width = 150;
        }
        if (height > 0) {
            intent.putExtra("outputY", height);
        } else {
            intent.putExtra("outputY", 150);
            height = 150;
        }
        if (width > 0 && height > 0 && width == height) {
            intent.putExtra("aspectX", 1);
            intent.putExtra("aspectY", 1);
        }
        intent.putExtra("return-data", false);
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
        intent.putExtra("scale", true);
        intent.putExtra("noFaceDetection", true);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        activity.startActivityForResult(intent, request_code);
    }

    /**
     * 指定图片路径截图
     */
    public static void cropCamera(Activity activity, Uri orgUri, Uri desUri, int width, int height, int request_code) {
        Intent intent = new Intent();
        intent.setAction("com.android.camera.action.CROP");
        intent.setDataAndType(orgUri, "image/*");
        intent.putExtra("crop", "true");
        if (width > 0) {
            intent.putExtra("outputX", width);
        } else {
            intent.putExtra("outputX", 150);
            width = 150;
        }
        if (height > 0) {
            intent.putExtra("outputY", height);
        } else {
            intent.putExtra("outputY", 150);
            height = 150;
        }
        if (width > 0 && height > 0 && width == height) {
            intent.putExtra("aspectX", 1);
            intent.putExtra("aspectY", 1);
        }
        intent.putExtra("return-data", false);
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
        intent.putExtra("scale", true);
        intent.putExtra("noFaceDetection", true);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, desUri);
        activity.startActivityForResult(intent, request_code);
    }


}
